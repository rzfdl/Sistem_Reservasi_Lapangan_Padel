<?php

namespace Database\Seeders;

use App\Models\Jadwal;
use App\Models\Lapangan;
use App\Models\Pembayaran;
use App\Models\Reservasi;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::create([
            'name' => 'Admin Padelku', 'username' => 'admin', 'email' => 'admin@padelku.test',
            'password' => 'admin123', 'role' => 'admin',
        ]);

        $dimas = User::create([
            'name' => 'Dimas Pratama', 'username' => 'dimas', 'email' => 'dimas@padelku.test',
            'password' => 'password', 'role' => 'pelanggan',
        ]);
        $salsa = User::create([
            'name' => 'Salsa Maharani', 'username' => 'salsa', 'email' => 'salsa@padelku.test',
            'password' => 'password', 'role' => 'pelanggan',
        ]);

        // Data lapangan; slot jadwal 30 hari dibuat otomatis oleh model Lapangan.
        $l1 = Lapangan::create(['nama' => 'Lapangan 1', 'harga_sewa' => 150000, 'keterangan' => 'Indoor dengan dinding kaca panorama dan pencahayaan LED.']);
        $l2 = Lapangan::create(['nama' => 'Lapangan 2', 'harga_sewa' => 150000, 'keterangan' => 'Indoor, lantai turf biru, tersedia ruang ganti.']);
        $l3 = Lapangan::create(['nama' => 'Lapangan 3', 'harga_sewa' => 120000, 'keterangan' => 'Outdoor beratap, cocok untuk main santai pagi dan sore.']);
        $l4 = Lapangan::create(['nama' => 'Lapangan 4', 'harga_sewa' => 200000, 'keterangan' => 'Indoor VIP dengan AC, tribun mini, dan loker pribadi.']);

        // Contoh bukti pembayaran (placeholder SVG)
        Storage::disk('local')->put('bukti/contoh-bukti.svg',
            '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="420"><rect width="320" height="420" fill="#fff"/>'
            .'<circle cx="160" cy="80" r="30" fill="#D1FAE5"/><path d="M146 80l10 10 20-24" stroke="#065F46" stroke-width="5" fill="none"/>'
            .'<text x="160" y="150" font-size="18" text-anchor="middle" font-family="Arial">Transfer berhasil</text>'
            .'<text x="160" y="190" font-size="28" font-weight="bold" text-anchor="middle" font-family="Arial">Rp50.000</text></svg>');

        $slot = fn (Lapangan $l, int $hariKe, int $jam) => Jadwal::where('lapangan_id', $l->id)
            ->whereDate('tanggal', today()->addDays($hariKe))
            ->where('jam_mulai', sprintf('%02d:00:00', $jam))->firstOrFail();

        $buat = function (User $u, Jadwal $j, string $status, ?string $hasil = null) {
            $r = Reservasi::create(['user_id' => $u->id, 'jadwal_id' => $j->id, 'status' => $status]);
            $r->update(['kode' => sprintf('RSV-%04d', $r->id)]);
            if ($hasil) {
                Pembayaran::create([
                    'reservasi_id' => $r->id, 'bukti_path' => 'bukti/contoh-bukti.svg', 'nominal' => 50000,
                    'status' => $hasil,
                    'diverifikasi_at' => $hasil === Pembayaran::MENUNGGU ? null : now(),
                ]);
            }
        };

        $buat($dimas, $slot($l2, 1, 19), Reservasi::MENUNGGU_PEMBAYARAN);
        $buat($dimas, $slot($l1, 3, 20), Reservasi::MENUNGGU_VERIFIKASI, Pembayaran::MENUNGGU);
        $buat($dimas, $slot($l4, 2, 18), Reservasi::TERKONFIRMASI, Pembayaran::DITERIMA);
        $buat($dimas, $slot($l3, 4, 16), Reservasi::MENUNGGU_PEMBAYARAN, Pembayaran::DITOLAK);
        $buat($salsa, $slot($l3, 1, 16), Reservasi::MENUNGGU_VERIFIKASI, Pembayaran::MENUNGGU);
        $buat($salsa, $slot($l4, 2, 19), Reservasi::MENUNGGU_VERIFIKASI, Pembayaran::MENUNGGU);
    }
}
