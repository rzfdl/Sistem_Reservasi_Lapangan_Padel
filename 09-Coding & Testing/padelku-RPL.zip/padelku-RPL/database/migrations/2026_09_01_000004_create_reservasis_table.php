<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reservasis', function (Blueprint $table) {
            $table->id();
            $table->string('kode', 20)->nullable()->unique();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            // NFR-17: satu slot hanya dapat dipesan oleh paling banyak satu reservasi
            $table->foreignId('jadwal_id')->unique()->constrained('jadwals')->restrictOnDelete();
            $table->string('status', 30)->default('Menunggu Pembayaran');
            $table->timestamps();

            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reservasis');
    }
};
