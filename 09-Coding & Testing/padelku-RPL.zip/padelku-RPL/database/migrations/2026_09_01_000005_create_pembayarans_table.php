<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pembayarans', function (Blueprint $table) {
            $table->id();
            // NFR-20: satu reservasi boleh punya lebih dari satu pembayaran
            $table->foreignId('reservasi_id')->constrained('reservasis')->cascadeOnDelete();
            $table->string('bukti_path');
            $table->unsignedBigInteger('nominal');
            $table->string('status', 20)->default('Menunggu'); // Menunggu | Diterima | Ditolak
            $table->timestamp('diverifikasi_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pembayarans');
    }
};
