<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // NFR-08: role-based access control (pelanggan / admin)
        $middleware->alias([
            'role' => \App\Http\Middleware\RoleMiddleware::class,
        ]);

        $middleware->redirectUsersTo(fn () => auth()->user()?->isAdmin()
            ? route('admin.dashboard')
            : route('pelanggan.dashboard'));
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
