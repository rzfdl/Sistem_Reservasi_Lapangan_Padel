<?php

use Illuminate\Support\Facades\Schedule;

// NFR-04: backup data transaksi otomatis harian
Schedule::command('padel:backup')->dailyAt('01:00');

// Memperpanjang slot jadwal 30 hari ke depan setiap hari
Schedule::command('padel:generate-jadwal')->dailyAt('00:30');
