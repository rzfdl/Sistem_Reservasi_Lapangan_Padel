<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\PelangganController;
use App\Http\Controllers\PembayaranController;
use App\Http\Controllers\ReservasiController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/jadwal');

// Publik (tanpa login): FR-7
Route::get('/jadwal', [JadwalController::class, 'index'])->name('jadwal');

// Autentikasi: FR-1, FR-2
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login.attempt');
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// File bukti pembayaran (admin atau pemilik)
Route::get('/bukti/{pembayaran}', [PembayaranController::class, 'bukti'])->middleware('auth')->name('bukti');

// Pelanggan
Route::middleware(['auth', 'role:pelanggan'])->group(function () {
    Route::get('/beranda', [PelangganController::class, 'dashboard'])->name('pelanggan.dashboard');
    Route::get('/reservasi/buat', [ReservasiController::class, 'create'])->name('reservasi.create');
    Route::post('/reservasi', [ReservasiController::class, 'store'])->name('reservasi.store');
    Route::get('/reservasi', [ReservasiController::class, 'index'])->name('reservasi.index');
    Route::get('/reservasi/{reservasi}/pembayaran', [PembayaranController::class, 'create'])->name('pembayaran.create');
    Route::post('/reservasi/{reservasi}/pembayaran', [PembayaranController::class, 'store'])->name('pembayaran.store');
});

// Admin
Route::middleware(['auth', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('lapangan', Admin\LapanganController::class)->only(['index', 'store', 'update', 'destroy']);
    Route::get('/verifikasi', [Admin\VerifikasiController::class, 'index'])->name('verifikasi.index');
    Route::post('/verifikasi/{pembayaran}/terima', [Admin\VerifikasiController::class, 'terima'])->name('verifikasi.terima');
    Route::post('/verifikasi/{pembayaran}/tolak', [Admin\VerifikasiController::class, 'tolak'])->name('verifikasi.tolak');
    Route::get('/laporan', [Admin\LaporanController::class, 'index'])->name('laporan.index');
});
