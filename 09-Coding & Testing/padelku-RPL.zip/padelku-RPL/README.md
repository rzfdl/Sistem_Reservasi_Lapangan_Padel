# Padelku: Sistem Reservasi Lapangan Padel

Implementasi perangkat lunak berdasarkan SRS dan desain UI. Arsitektur MVC dengan Laravel 11/12, PHP 8.2+, MySQL 8, dan Nginx.

Folder ini adalah **lapisan kode aplikasi** (overlay). Ia ditimpa ke proyek Laravel baru, jadi `vendor/` tidak ikut disertakan.

## Cara menjalankan

```bash
# 1. Buat proyek Laravel kosong
composer create-project laravel/laravel padelku "^11.0"

# 2. Salin isi folder ini ke dalam proyek, timpa file yang bentrok
#    (bootstrap/app.php, routes/console.php, AppServiceProvider, User.php)
cp -r padelku-src/. padelku/
cd padelku

# 3. Atur environment
cp .env.example .env
#    salin pengaturan dari .env.padelku.example ke .env (DB, timezone, sesi 30 menit)
php artisan key:generate

# 4. Buat database "padelku" di MySQL, lalu migrasi + data contoh
php artisan migrate --seed

# 5. Jalankan
php artisan serve        # http://localhost:8000
```

Akun contoh (dari seeder):

| Peran | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Pelanggan | `dimas` | `password` |
| Pelanggan | `salsa` | `password` |

Ganti password akun contoh sebelum dipakai di server nyata.

Pengujian: `php artisan test` (memakai SQLite in-memory bawaan Laravel).

## Penjadwalan (cron)

```
* * * * * cd /var/www/padelku && php artisan schedule:run >> /dev/null 2>&1
```

- `padel:generate-jadwal` (00.30): memperpanjang slot jadwal 30 hari ke depan
- `padel:backup` (01.00): backup harian database dengan `mysqldump` ke `storage/app/private/backup` (NFR-04). Server perlu memiliki `mysqldump`.

## Pemetaan UI, kode, dan SRS

| UI | Route | Controller | View | Kebutuhan |
|---|---|---|---|---|
| LoginUI | `/login` | `AuthController` | `auth/login` | FR-1, FR-2 |
| JadwalUI | `/jadwal` | `JadwalController` | `jadwal/index` | FR-7 |
| ReservasiUI | `/reservasi/buat` | `ReservasiController@create,store` | `reservasi/create` | FR-8, FR-9, NFR-17 |
| UploadUI | `/reservasi/{id}/pembayaran` | `PembayaranController` | `pembayaran/create` | FR-11, FR-12, NFR-05 |
| StatusUI | `/reservasi` | `ReservasiController@index` | `reservasi/index` | FR-10, NFR-19 |
| Dashboard pelanggan | `/beranda` | `PelangganController` | `pelanggan/dashboard` | - |
| Dashboard admin | `/admin` | `Admin\DashboardController` | `admin/dashboard` | - |
| LapanganUI | `/admin/lapangan` | `Admin\LapanganController` | `admin/lapangan/index` | FR-3 sampai FR-6, NFR-06 |
| VerifikasiUI | `/admin/verifikasi` | `Admin\VerifikasiController` | `admin/verifikasi/index` | FR-13, FR-14 |
| LaporanUI | `/admin/laporan` | `Admin\LaporanController` | `admin/laporan/index` | FR-15 |

## Keputusan teknis

- **Anti double-booking (NFR-17):** kolom `reservasis.jadwal_id` bersifat `UNIQUE` di database, ditambah `lockForUpdate()` dalam transaksi. Jika dua pelanggan menekan tombol bersamaan, hanya satu yang berhasil dan yang lain mendapat "Slot Sudah Terisi".
- **Alur status (NFR-19):** Menunggu Pembayaran → Menunggu Verifikasi → Terkonfirmasi. Bukti ditolak mengembalikan status ke Menunggu Pembayaran. Satu reservasi bisa punya banyak pembayaran (NFR-20).
- **Keamanan:** password di-hash bcrypt (NFR-07), middleware `role` untuk RBAC (NFR-08), pelanggan hanya bisa membuka reservasinya sendiri (NFR-18), file bukti disimpan di disk privat dan hanya bisa dibuka admin atau pemiliknya, CSRF aktif, login dibatasi 10 percobaan per menit, HTTPS dipaksa saat `APP_ENV=production` (NFR-10).
- **Sesi (NFR-09):** `SESSION_LIFETIME=30` di server, ditambah timer idle di browser yang menampilkan modal "Sesi kamu berakhir".
- **Slot jadwal:** dibuat otomatis per jam (08.00–22.00) untuk 30 hari ke depan saat lapangan ditambahkan. Jam buka diatur di `Jadwal::JAM_BUKA` dan `JAM_TUTUP`.
- **Penghapusan lapangan:** ditolak bila lapangan masih punya reservasi, supaya riwayat transaksi tidak hilang.
- **Responsif:** `public/css/app.css` memakai breakpoint 1000 px untuk tablet dan ponsel.
