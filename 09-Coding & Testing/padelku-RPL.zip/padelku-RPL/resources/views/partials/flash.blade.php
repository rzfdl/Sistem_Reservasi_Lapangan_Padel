@if (session('sukses'))
    <div class="alert ok" style="margin-bottom:20px">
        <x-icon name="check" :size="20" color="#0B5B3B" :w="2.2" />
        <div>{{ session('sukses') }}</div>
    </div>
@endif
@foreach (['hapus', 'verifikasi'] as $kunci)
    @error($kunci)
        <div class="alert err" style="margin-bottom:20px">
            <x-icon name="alert" :size="20" color="#8F1D1D" />
            <div>{{ $message }}</div>
        </div>
    @enderror
@endforeach
