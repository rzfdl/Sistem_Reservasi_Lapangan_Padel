{{-- NFR-09: sesi berakhir setelah 30 menit tidak aktif --}}
<div class="overlay" id="modalSesi">
    <div class="modal">
        <div class="mico" style="background:#FEF3C7"><x-icon name="clock" :size="28" color="#92400E" /></div>
        <h2>Sesi kamu berakhir</h2>
        <p>Demi keamanan, kamu keluar otomatis setelah 30 menit tidak aktif. Masuk lagi untuk melanjutkan.</p>
        <a class="btn primary block" href="{{ route('login') }}">Masuk lagi</a>
    </div>
</div>
@push('scripts')
<script>
(function () {
    var batas = 30 * 60 * 1000, timer;
    function habis() {
        document.getElementById('modalSesi').classList.add('open');
        fetch('{{ route("logout") }}', {method: 'POST', headers: {'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content}});
    }
    function reset() { clearTimeout(timer); timer = setTimeout(habis, batas); }
    ['click', 'keydown', 'mousemove', 'touchstart'].forEach(function (e) { addEventListener(e, reset, {passive: true}); });
    reset();
})();
</script>
@endpush
