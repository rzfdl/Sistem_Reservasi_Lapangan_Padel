@extends('layouts.plain')
@section('title', 'Masuk')
@section('content')
<div class="login">
    <section class="hero">
        <div class="brand light"><x-logo /><span>Padelku</span></div>
        <div class="art"><x-court :w="400" :h="473" /></div>
        <div>
            <h1>Pesan lapangan padel tanpa chat bolak-balik</h1>
            <p>Cek slot kosong, reservasi, dan unggah bukti DP di satu tempat. Admin yang memverifikasi, kamu tinggal main.</p>
        </div>
    </section>
    <section class="formside">
        <form class="formbox" method="POST" action="{{ route('login.attempt') }}">
            @csrf
            <div>
                <h1>Masuk ke akun</h1>
                <p style="margin-top:8px">Pelanggan dan admin masuk dari halaman yang sama.</p>
            </div>
            @if ($errors->any())
                <div class="alert err">
                    <x-icon name="alert" :size="20" color="#8F1D1D" />
                    <div><b>{{ $errors->first() }}</b>Periksa kembali data kamu, lalu coba masuk lagi.</div>
                </div>
            @endif
            <div class="field">
                <label for="username">Username</label>
                <div class="input {{ $errors->any() ? 'err' : '' }}">
                    <x-icon name="user" :size="18" color="#5B6B82" />
                    <input id="username" name="username" value="{{ old('username') }}" placeholder="Masukkan username" autocomplete="username" autofocus>
                </div>
            </div>
            <div class="field">
                <label for="password">Password</label>
                <div class="input {{ $errors->any() ? 'err' : '' }}">
                    <x-icon name="lock" :size="18" color="#5B6B82" />
                    <input id="password" type="password" name="password" placeholder="Masukkan password" autocomplete="current-password">
                    <button type="button" id="lihatPw" style="background:none;border:0;cursor:pointer;display:flex" aria-label="Tampilkan password"><x-icon name="eye" :size="18" color="#8A97AB" /></button>
                </div>
            </div>
            <button type="submit" class="btn primary block">Masuk</button>
            <div class="divider"><i></i>atau<i></i></div>
            <a class="btn ghost block" href="{{ route('jadwal') }}"><x-icon name="calendar" :size="18" />Lihat jadwal lapangan tanpa login</a>
            <p class="hint" style="text-align:center">Sesi berakhir otomatis setelah 30 menit tidak aktif.</p>
        </form>
    </section>
</div>
@endsection
@push('scripts')
<script>
document.getElementById('lihatPw').addEventListener('click', function () {
    var p = document.getElementById('password');
    p.type = p.type === 'password' ? 'text' : 'password';
});
</script>
@endpush
