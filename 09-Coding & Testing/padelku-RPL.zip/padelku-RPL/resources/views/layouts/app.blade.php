<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - Padelku</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
<header class="topnav">
    <a class="brand" href="{{ route('jadwal') }}"><x-logo /><span>Padelku</span></a>
    <nav class="links">
        @auth
            @if (auth()->user()->isAdmin())
                <a href="{{ route('jadwal') }}" class="on">Jadwal</a>
                <a href="{{ route('admin.dashboard') }}">Panel admin</a>
            @else
                <a href="{{ route('pelanggan.dashboard') }}" class="{{ request()->routeIs('pelanggan.dashboard') ? 'on' : '' }}">Beranda</a>
                <a href="{{ route('jadwal') }}" class="{{ request()->routeIs('jadwal') ? 'on' : '' }}">Jadwal</a>
                <a href="{{ route('reservasi.create') }}" class="{{ request()->routeIs('reservasi.create') ? 'on' : '' }}">Buat Reservasi</a>
                <a href="{{ route('reservasi.index') }}" class="{{ request()->routeIs('reservasi.index', 'pembayaran.*') ? 'on' : '' }}">Status Reservasi</a>
            @endif
        @else
            <a href="{{ route('jadwal') }}" class="on">Jadwal</a>
        @endauth
    </nav>
    <div class="right">
        @auth
            <div class="avatar">{{ auth()->user()->inisial }}</div>
            <div class="uname">{{ auth()->user()->name }}<small>{{ auth()->user()->isAdmin() ? 'Admin' : 'Pelanggan' }}</small></div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn ghost sm"><x-icon name="logout" :size="16" />Keluar</button>
            </form>
        @else
            <a class="btn primary sm" href="{{ route('login') }}">Masuk</a>
        @endauth
    </div>
</header>

@yield('content')

@auth
    @include('partials.sesi')
@endauth
@stack('scripts')
</body>
</html>
