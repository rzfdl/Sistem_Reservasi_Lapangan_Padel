<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - Padelku</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
@php
$menu = [
    ['admin.dashboard', 'admin.dashboard', 'Dashboard', 'home'],
    ['admin.lapangan.*', 'admin.lapangan.index', 'Manajemen Lapangan', 'court'],
    ['admin.verifikasi.*', 'admin.verifikasi.index', 'Verifikasi Pembayaran', 'shield'],
    ['admin.laporan.*', 'admin.laporan.index', 'Laporan Transaksi', 'chart'],
];
@endphp
<div class="adm">
    <aside class="sidebar">
        <a class="brand light" href="{{ route('admin.dashboard') }}"><x-logo /><span>Padelku</span></a>
        <div class="role">Admin pengelola lapangan</div>
        @foreach ($menu as $item)
            @php $aktif = request()->routeIs($item[0]); @endphp
            <a class="sbi {{ $aktif ? 'on' : '' }}" href="{{ route($item[1]) }}">
                <x-icon :name="$item[3]" :size="20" :color="$aktif ? '#CBEA2E' : '#9FB2CE'" /><span>{{ $item[2] }}</span>
            </a>
        @endforeach
        <form method="POST" action="{{ route('logout') }}" style="margin-top:auto">
            @csrf
            <button type="submit" class="sbi"><x-icon name="logout" :size="20" color="#9FB2CE" /><span>Keluar</span></button>
        </form>
    </aside>
    <main class="adm-main">
        <header class="adm-head">
            <div><h1>@yield('heading')</h1><p>@yield('sub')</p></div>
            <div class="adm-actions">@yield('actions')<div class="avatar">{{ auth()->user()->inisial }}</div></div>
        </header>
        <div class="adm-body">
            @include('partials.flash')
            @yield('content')
        </div>
    </main>
</div>
@include('partials.sesi')
@stack('scripts')
</body>
</html>
