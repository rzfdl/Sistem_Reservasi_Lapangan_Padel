@props(['status'])
@php
$warna = ['Menunggu Pembayaran' => 'amber', 'Menunggu Verifikasi' => 'blue', 'Terkonfirmasi' => 'green', 'Diterima' => 'green', 'Ditolak' => 'red', 'Menunggu' => 'blue'];
@endphp
<span class="chip {{ $warna[$status] ?? 'blue' }}"><i class="dot"></i>{{ $status }}</span>
