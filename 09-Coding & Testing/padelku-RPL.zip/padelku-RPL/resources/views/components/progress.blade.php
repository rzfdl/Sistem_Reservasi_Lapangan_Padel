@props(['stage'])
<div>
    <div class="seg">
        @foreach ([1, 2, 3] as $k)
            <i class="{{ $stage >= $k ? ($stage == 3 ? 'g' : 'f') : '' }}"></i>
        @endforeach
    </div>
    <div class="segl"><span>Bayar</span><span>Verifikasi</span><span>Terkonfirmasi</span></div>
</div>
