@props(['name', 'size' => 20, 'color' => '#0B1F3A', 'w' => 1.8])
@php
$paths = [
    'home' => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    'court' => '<rect x="3" y="5" width="18" height="14" rx="1"/><path d="M12 5v14M3 12h18"/>',
    'check' => '<path d="M5 12l5 5 9-10"/>',
    'shield' => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
    'chart' => '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
    'logout' => '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
    'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    'upload' => '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    'lock' => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
    'eye' => '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    'plus' => '<path d="M12 5v14M5 12h14"/>',
    'pencil' => '<path d="M4 20l4-1 11-11-3-3L5 16z"/>',
    'trash' => '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    'x' => '<path d="M6 6l12 12M18 6L6 18"/>',
    'alert' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16.5v.5"/>',
    'info' => '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
    'file' => '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/>',
    'chevL' => '<path d="M15 5l-7 7 7 7"/>',
    'chevR' => '<path d="M9 5l7 7-7 7"/>',
    'chevD' => '<path d="M5 9l7 7 7-7"/>',
    'clip' => '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6v3H9zM9 12h6M9 16h4"/>',
    'menu' => '<path d="M4 7h16M4 12h16M4 17h16"/>',
    'image' => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 17l-6-6-8 9"/>'
];
@endphp
<svg width="{{ $size }}" height="{{ $size }}" viewBox="0 0 24 24" fill="none" stroke="{{ $color }}" stroke-width="{{ $w }}" stroke-linecap="round" stroke-linejoin="round" style="flex:none">{!! $paths[$name] ?? '' !!}</svg>
