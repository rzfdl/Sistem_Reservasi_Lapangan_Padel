@props(['size' => 32])
<svg width="{{ $size }}" height="{{ $size }}" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="15" fill="#CBEA2E"/><path d="M5 8c7 4 7 12 0 16M27 8c-7 4-7 12 0 16" stroke="#0B1F3A" stroke-width="1.8" stroke-linecap="round"/></svg>
