@props(['step' => 1])
@php $names = ['Pilih slot', 'Unggah bukti', 'Verifikasi admin']; @endphp
<div class="flow">
    @foreach ($names as $i => $n)
        @php $no = $i + 1; $cls = $no < $step ? 'done' : ($no == $step ? 'on' : ''); @endphp
        <div class="fs {{ $cls }}">
            <span class="fc">@if ($no < $step)<x-icon name="check" :size="16" color="#fff" :w="2.4" />@else{{ $no }}@endif</span>
            <span>{{ $n }}</span>
        </div>
        @if (! $loop->last)<div class="fl"></div>@endif
    @endforeach
</div>
