@extends('layouts.app')
@section('title', 'Jadwal lapangan')
@section('content')
<div class="page">
    @include('partials.flash')
    <div class="phead">
        <div><h1>Jadwal lapangan</h1><p>Lihat slot yang masih kosong per tanggal.</p></div>
        @if (! $kosong && $lapangans->isNotEmpty())
            <div class="legend">
                <span><i class="lg free"></i>Tersedia</span><span><i class="lg busy"></i>Terisi</span><span><i class="lg sel"></i>Dipilih</span>
            </div>
        @endif
    </div>

    <div class="jad">
        <div class="col">
            <form class="datebar" method="GET" action="{{ route('jadwal') }}">
                @if ($sebelumnya)
                    <a class="sq" href="{{ route('jadwal', ['tanggal' => $sebelumnya->toDateString()]) }}"><x-icon name="chevL" :size="18" /></a>
                @else
                    <span class="sq" style="opacity:.4"><x-icon name="chevL" :size="18" /></span>
                @endif
                @foreach ($strip as $d)
                    <a class="dchip {{ $d->isSameDay($tgl) ? 'on' : '' }}" href="{{ route('jadwal', ['tanggal' => $d->toDateString()]) }}">
                        <small>{{ $d->translatedFormat('D') }}</small><b>{{ $d->day }}</b>
                    </a>
                @endforeach
                @if ($berikutnya)
                    <a class="sq" href="{{ route('jadwal', ['tanggal' => $berikutnya->toDateString()]) }}"><x-icon name="chevR" :size="18" /></a>
                @else
                    <span class="sq" style="opacity:.4"><x-icon name="chevR" :size="18" /></span>
                @endif
                <div class="input" style="width:210px;margin-left:auto">
                    <x-icon name="calendar" :size="18" color="#5B6B82" />
                    <input type="date" name="tanggal" value="{{ $tgl->toDateString() }}" min="{{ $min->toDateString() }}" max="{{ $max->toDateString() }}" onchange="this.form.submit()">
                </div>
            </form>

            <h2 class="sec">{{ $tgl->translatedFormat('l, j F Y') }}</h2>

            @if ($lapangans->isEmpty())
                <div class="empty">
                    <div class="eico"><x-icon name="court" :size="44" color="#1B4FB5" /></div>
                    <h2>Belum Ada Lapangan</h2>
                    <p>Data lapangan belum tersedia. Silakan kembali lagi nanti.</p>
                </div>
            @elseif ($kosong)
                {{-- FR-7: tidak ada slot tersedia --}}
                <div class="empty">
                    <div class="eico"><x-icon name="court" :size="44" color="#1B4FB5" /></div>
                    <h2>Slot Tidak Tersedia</h2>
                    <p>Semua slot pada {{ $tgl->translatedFormat('l, j F Y') }} sudah terisi. Coba pilih tanggal lain.</p>
                    @if ($berikutnya)
                        <a class="btn ghost" href="{{ route('jadwal', ['tanggal' => $berikutnya->toDateString()]) }}">Lihat {{ $berikutnya->translatedFormat('l, j F Y') }}</a>
                    @endif
                </div>
            @else
                <div class="card flush" style="overflow-x:auto">
                    <div class="grid" style="grid-template-columns:120px repeat({{ $lapangans->count() }}, minmax(130px, 1fr)); min-width:640px">
                        <div class="gh"></div>
                        @foreach ($lapangans as $l)
                            <div class="gh">{{ $l->nama }}<small>@rupiah($l->harga_sewa)/jam</small></div>
                        @endforeach
                        @foreach ($jamList as $jam => $label)
                            <div class="gt">{{ $label }}</div>
                            @foreach ($lapangans as $l)
                                @php $j = $matrix[$jam][$l->id] ?? null; @endphp
                                <div class="gc">
                                    @if (! $j)
                                        <div class="slot busy">-</div>
                                    @elseif ($j->tersedia)
                                        <button type="button" class="slot free"
                                                data-id="{{ $j->id }}" data-lapangan="{{ $l->nama }}"
                                                data-jam="{{ $label }}" data-harga="Rp{{ number_format($l->harga_sewa, 0, ',', '.') }}">Tersedia</button>
                                    @else
                                        <div class="slot busy">{{ $j->lewat ? 'Lewat' : 'Terisi' }}</div>
                                    @endif
                                </div>
                            @endforeach
                        @endforeach
                    </div>
                </div>
            @endif
        </div>

        <aside class="col">
            <div class="card" id="panelKosong">
                <div class="eico s" style="margin-bottom:16px"><x-icon name="calendar" :size="26" color="#1B4FB5" /></div>
                <h2>Pilih slot kosong</h2>
                @guest
                    <p class="sub" style="margin-bottom:20px">Melihat jadwal tidak perlu login. Kamu hanya perlu masuk saat membuat reservasi.</p>
                    <a class="btn primary block" href="{{ route('login') }}">Masuk untuk memesan</a>
                @else
                    <p class="sub" style="margin-bottom:0">Klik salah satu slot berwarna biru muda untuk memilih jam main.</p>
                @endguest
            </div>

            <div class="card" id="panelPilih" hidden>
                <h2 style="margin-bottom:8px">Slot dipilih</h2>
                <div class="kv"><span>Lapangan</span><b id="pLap"></b></div>
                <div class="kv"><span>Tanggal</span><b>{{ $tgl->translatedFormat('l, j F Y') }}</b></div>
                <div class="kv"><span>Jam main</span><b id="pJam"></b></div>
                <div class="kv total"><span>Harga sewa</span><b id="pHarga"></b></div>
                <a id="pLink" class="btn primary block" style="margin-top:16px" href="#">
                    @guest Masuk untuk memesan @else Lanjut ke reservasi @endguest
                </a>
            </div>

            <div class="card">
                <h2 style="margin-bottom:8px">Harga sewa</h2>
                @foreach ($lapangans as $l)
                    <div class="kv"><span>{{ $l->nama }}</span><b>@rupiah($l->harga_sewa)/jam</b></div>
                @endforeach
            </div>
        </aside>
    </div>
</div>
@endsection
@push('scripts')
<script>
(function () {
    var base = "{{ route('reservasi.create') }}";
    var aktif = null;
    document.querySelectorAll('.slot.free').forEach(function (b) {
        b.addEventListener('click', function () {
            if (aktif) { aktif.classList.remove('sel'); aktif.classList.add('free'); aktif.textContent = 'Tersedia'; }
            aktif = b;
            b.classList.remove('free'); b.classList.add('sel'); b.textContent = 'Dipilih';
            document.getElementById('pLap').textContent = b.dataset.lapangan;
            document.getElementById('pJam').textContent = b.dataset.jam;
            document.getElementById('pHarga').textContent = b.dataset.harga;
            document.getElementById('pLink').href = base + '?jadwal_id=' + b.dataset.id;
            document.getElementById('panelKosong').hidden = true;
            document.getElementById('panelPilih').hidden = false;
        });
    });
})();
</script>
@endpush
