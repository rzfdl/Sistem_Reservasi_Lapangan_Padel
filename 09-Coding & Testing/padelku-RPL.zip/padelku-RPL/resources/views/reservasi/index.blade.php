@extends('layouts.app')
@section('title', 'Status reservasi')
@section('content')
<div class="page">
    @include('partials.flash')
    <div class="phead">
        <div><h1>Status reservasi</h1><p>Pantau perkembangan semua reservasimu.</p></div>
    </div>

    @if ($total === 0)
        {{-- FR-10 --}}
        <div class="empty">
            <div class="eico"><x-icon name="clip" :size="44" color="#1B4FB5" /></div>
            <h2>Belum Ada Reservasi</h2>
            <p>Reservasi yang kamu buat akan muncul di sini beserta statusnya.</p>
            <a class="btn primary" href="{{ route('jadwal') }}">Lihat jadwal lapangan</a>
        </div>
    @else
        <div class="pills" style="flex-wrap:wrap">
            <a class="pill {{ ! $filter ? 'on' : '' }}" href="{{ route('reservasi.index') }}">Semua ({{ $total }})</a>
            @foreach ($statuses as $s)
                <a class="pill {{ $filter === $s ? 'on' : '' }}" href="{{ route('reservasi.index', ['status' => $s]) }}">{{ $s }} ({{ $counts[$s] ?? 0 }})</a>
            @endforeach
        </div>

        @forelse ($daftar as $r)
            <div class="rcard">
                <div class="rrow">
                    <div class="rc1"><b>{{ $r->jadwal->lapangan->nama }}</b><span>{{ $r->kode }}</span></div>
                    <div class="rc2"><b>{{ $r->jadwal->tanggal->translatedFormat('l, j F Y') }}</b><span>{{ $r->jadwal->label_jam }}</span></div>
                    <div class="rc3"><x-progress :stage="$r->tahap" /></div>
                    <div class="rc4">
                        <x-chip :status="$r->status" />
                        @if ($r->status === 'Menunggu Pembayaran')
                            <a class="btn primary sm" href="{{ route('pembayaran.create', $r) }}">{{ $r->ditolak ? 'Unggah ulang bukti' : 'Unggah bukti' }}</a>
                        @elseif ($r->status === 'Menunggu Verifikasi')
                            <span class="hint">Admin sedang memeriksa bukti</span>
                        @else
                            <span class="hint">Slot sudah menjadi milikmu</span>
                        @endif
                    </div>
                </div>
                @if ($r->ditolak)
                    <div class="alert warn">
                        <x-icon name="alert" :size="18" color="#7A4A06" />
                        <div>Bukti pembayaran ditolak admin. Unggah ulang bukti agar reservasi bisa diverifikasi lagi.</div>
                    </div>
                @endif
            </div>
        @empty
            <p class="hint">Tidak ada reservasi dengan status ini.</p>
        @endforelse
    @endif
</div>
@endsection
