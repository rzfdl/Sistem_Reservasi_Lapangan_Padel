@extends('layouts.app')
@section('title', 'Buat reservasi')
@section('content')
<div class="page">
    @include('partials.flash')
    <div class="phead">
        <div><h1>Buat reservasi</h1><p>Satu slot hanya bisa dipesan oleh satu reservasi.</p></div>
        <x-flow :step="1" />
    </div>

    @if (! $lapangan)
        <div class="empty">
            <div class="eico"><x-icon name="court" :size="44" color="#1B4FB5" /></div>
            <h2>Belum Ada Lapangan</h2>
            <p>Data lapangan belum tersedia, reservasi belum bisa dibuat.</p>
        </div>
    @else
    <div class="two">
        <div class="card">
            <h2>Detail reservasi</h2>
            <p class="sub">Pilih lapangan, tanggal, dan jam main.</p>

            <div style="display:flex;flex-direction:column;gap:20px">
                <form method="GET" action="{{ route('reservasi.create') }}" class="two2">
                    <div class="field">
                        <label for="lapangan_id">Lapangan</label>
                        <div class="input">
                            <select id="lapangan_id" name="lapangan_id" onchange="this.form.submit()">
                                @foreach ($lapangans as $l)
                                    <option value="{{ $l->id }}" @selected($l->id === $lapangan->id)>{{ $l->nama }}</option>
                                @endforeach
                            </select>
                            <x-icon name="chevD" :size="18" color="#5B6B82" />
                        </div>
                    </div>
                    <div class="field">
                        <label for="tanggal">Tanggal</label>
                        <div class="input">
                            <x-icon name="calendar" :size="18" color="#5B6B82" />
                            <input id="tanggal" type="date" name="tanggal" value="{{ $tgl->toDateString() }}" min="{{ today()->toDateString() }}" onchange="this.form.submit()">
                        </div>
                    </div>
                </form>

                {{-- FR-9 --}}
                @if (session('slot_terisi'))
                    <div class="alert err">
                        <x-icon name="alert" :size="20" color="#8F1D1D" />
                        <div><b>Slot Sudah Terisi</b>Slot yang kamu pilih baru saja dipesan pelanggan lain. Pilih slot lain.</div>
                    </div>
                @endif
                @error('jadwal_id')
                    <div class="alert err"><x-icon name="alert" :size="20" color="#8F1D1D" /><div><b>{{ $message }}</b></div></div>
                @enderror

                <form method="POST" action="{{ route('reservasi.store') }}" id="storeForm">
                    @csrf
                    <div class="field">
                        <label>Jam main di {{ $lapangan->nama }}</label>
                        @if ($jadwals->isEmpty())
                            <p class="hint">Belum ada slot pada tanggal ini.</p>
                        @else
                            <div class="tcs" style="grid-template-columns:repeat(4,1fr)">
                                @foreach ($jadwals as $j)
                                    @if ($j->tersedia)
                                        <label class="tc free">
                                            <input type="radio" name="jadwal_id" value="{{ $j->id }}" data-jam="{{ $j->label_jam }}"
                                                   @checked((int) old('jadwal_id', $dipilih?->id) === $j->id)>
                                            {{ $j->label_jam }}
                                        </label>
                                    @else
                                        <div class="tc busy">{{ $j->label_jam }}</div>
                                    @endif
                                @endforeach
                            </div>
                        @endif
                    </div>
                </form>

                <div class="legend">
                    <span><i class="lg free"></i>Tersedia</span><span><i class="lg busy"></i>Terisi</span><span><i class="lg sel"></i>Dipilih</span>
                </div>
            </div>
        </div>

        <aside class="col">
            <div class="card">
                <h2 style="margin-bottom:8px">Ringkasan</h2>
                <div class="kv"><span>Lapangan</span><b>{{ $lapangan->nama }}</b></div>
                <div class="kv"><span>Tanggal</span><b>{{ $tgl->translatedFormat('l, j F Y') }}</b></div>
                <div class="kv"><span>Jam main</span><b id="sumJam">{{ $dipilih?->label_jam ?? 'Belum dipilih' }}</b></div>
                <div class="kv total"><span>Harga sewa</span><b>@rupiah($lapangan->harga_sewa)</b></div>
                <button type="submit" form="storeForm" id="btnBuat" class="btn primary block" style="margin-top:16px" @disabled(! $dipilih && ! old('jadwal_id'))>Buat reservasi</button>
            </div>
            <div class="alert info">
                <x-icon name="info" :size="20" color="#17408F" />
                <div>Reservasi dibuat dengan status Menunggu Pembayaran. Reservasi sah setelah bukti DP diunggah dan diverifikasi admin.</div>
            </div>
        </aside>
    </div>
    @endif
</div>
@endsection
@push('scripts')
<script>
document.querySelectorAll('input[name=jadwal_id]').forEach(function (r) {
    r.addEventListener('change', function () {
        document.getElementById('sumJam').textContent = r.dataset.jam;
        document.getElementById('btnBuat').disabled = false;
    });
});
</script>
@endpush
