@extends('layouts.app')
@section('title', 'Beranda')
@section('content')
<div class="page">
    @include('partials.flash')
    <div class="phead">
        <div><h1>Halo, {{ \Illuminate\Support\Str::before(auth()->user()->name, ' ') }}</h1><p>Ini ringkasan reservasi kamu.</p></div>
    </div>
    <div class="jad">
        <div class="col">
            <div class="hero2">
                <div>
                    @if ($berikutnya)
                        <div class="k">Reservasi terkonfirmasi berikutnya</div>
                        <h2>{{ $berikutnya->jadwal->lapangan->nama }}</h2>
                        <p>{{ $berikutnya->jadwal->tanggal->translatedFormat('l, j F Y') }}, {{ $berikutnya->jadwal->label_jam }}</p>
                        <a class="btn ball" href="{{ route('reservasi.index') }}">Lihat status reservasi</a>
                    @else
                        <div class="k">Belum ada reservasi terkonfirmasi</div>
                        <h2>Mau main kapan?</h2>
                        <p>Cek slot kosong lalu pesan lapangan favoritmu.</p>
                        <a class="btn ball" href="{{ route('jadwal') }}">Lihat jadwal lapangan</a>
                    @endif
                </div>
                <x-court :w="150" :h="178" />
            </div>

            <div class="stats">
                @foreach ($statuses as $s)
                    <div class="stat"><x-chip :status="$s" /><span class="n">{{ $counts[$s] ?? 0 }}</span><span class="l">reservasi</span></div>
                @endforeach
            </div>

            <div class="card">
                <h2>Perlu tindakan</h2>
                <p class="sub">Unggah bukti DP agar admin bisa memverifikasi reservasimu.</p>
                @forelse ($perlu as $r)
                    <div class="arow">
                        <div>
                            <b>{{ $r->jadwal->lapangan->nama }}, {{ $r->jadwal->tanggal->translatedFormat('l, j F Y') }}</b>
                            <span class="s">{{ $r->jadwal->label_jam }}, {{ $r->kode }}</span>
                        </div>
                        <a class="btn primary sm" href="{{ route('pembayaran.create', $r) }}">{{ $r->ditolak ? 'Unggah ulang bukti' : 'Unggah bukti' }}</a>
                    </div>
                @empty
                    <p class="hint">Tidak ada yang perlu kamu lakukan sekarang.</p>
                @endforelse
            </div>
        </div>

        <aside class="card">
            <h2 style="margin-bottom:16px">Menu cepat</h2>
            <a class="qa" href="{{ route('jadwal') }}"><span class="qi"><x-icon name="calendar" :size="22" color="#1B4FB5" /></span><div>Lihat jadwal lapangan<small>Cek slot kosong per tanggal</small></div></a>
            <a class="qa" href="{{ route('reservasi.create') }}"><span class="qi"><x-icon name="plus" :size="22" color="#1B4FB5" /></span><div>Buat reservasi<small>Pilih slot dan pesan</small></div></a>
            <a class="qa" href="{{ route('reservasi.index') }}"><span class="qi"><x-icon name="clip" :size="22" color="#1B4FB5" /></span><div>Status reservasi<small>Pantau semua reservasimu</small></div></a>
        </aside>
    </div>
</div>
@endsection
