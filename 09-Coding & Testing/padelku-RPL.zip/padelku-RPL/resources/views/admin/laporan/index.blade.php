@extends('layouts.admin')
@section('title', 'Laporan transaksi')
@section('heading', 'Laporan transaksi')
@section('sub', 'Transaksi pembayaran per periode.')
@section('content')
<form class="card" method="GET" action="{{ route('admin.laporan.index') }}">
    <div style="display:flex;gap:20px;align-items:flex-end;flex-wrap:wrap">
        <div class="field" style="flex:1;min-width:200px"><label for="dari">Dari tanggal</label><div class="input"><x-icon name="calendar" :size="18" color="#5B6B82" /><input id="dari" type="date" name="dari" value="{{ $dari->toDateString() }}"></div></div>
        <div class="field" style="flex:1;min-width:200px"><label for="sampai">Sampai tanggal</label><div class="input"><x-icon name="calendar" :size="18" color="#5B6B82" /><input id="sampai" type="date" name="sampai" value="{{ $sampai->toDateString() }}"></div></div>
        <button type="submit" class="btn primary">Tampilkan laporan</button>
    </div>
    @error('sampai')<p class="errtxt" style="margin-top:10px">{{ $message }}</p>@enderror
    @error('dari')<p class="errtxt" style="margin-top:10px">{{ $message }}</p>@enderror
    <div class="pills" style="margin:16px 0 0;flex-wrap:wrap">
        <a class="pill" href="{{ route('admin.laporan.index', ['dari' => today()->subDays(6)->toDateString(), 'sampai' => today()->toDateString()]) }}">7 hari terakhir</a>
        <a class="pill" href="{{ route('admin.laporan.index', ['dari' => today()->startOfMonth()->toDateString(), 'sampai' => today()->toDateString()]) }}">Bulan ini</a>
        <a class="pill" href="{{ route('admin.laporan.index', ['dari' => today()->subMonthNoOverflow()->startOfMonth()->toDateString(), 'sampai' => today()->subMonthNoOverflow()->endOfMonth()->toDateString()]) }}">Bulan lalu</a>
    </div>
</form>

@if ($transaksi->isEmpty())
    <div class="empty">
        <div class="eico"><x-icon name="chart" :size="44" color="#1B4FB5" /></div>
        <h2>Data Tidak Ditemukan</h2>
        <p>Tidak ada transaksi pembayaran pada periode ini. Ubah rentang tanggal atau pilih periode lain.</p>
    </div>
@else
    <div class="stats">
        <div class="stat"><span class="l">Total pembayaran diterima</span><span class="n">@rupiah($totalDiterima)</span></div>
        <div class="stat"><span class="l">Transaksi diterima</span><span class="n">{{ $jumlahDiterima }}</span></div>
        <div class="stat"><span class="l">Transaksi ditolak</span><span class="n">{{ $jumlahDitolak }}</span></div>
    </div>
    <div class="card flush">
        <div class="tbl">
            @php $kolom = 'grid-template-columns:1fr 1fr 1.4fr 1fr 1fr 1fr'; @endphp
            <div class="tr th" style="{{ $kolom }}"><span>Tanggal</span><span>Kode</span><span>Pelanggan</span><span>Lapangan</span><span>Nominal</span><span>Hasil verifikasi</span></div>
            @foreach ($transaksi as $t)
                <div class="tr" style="{{ $kolom }}">
                    <span>{{ $t->created_at->translatedFormat('j M Y') }}</span>
                    <span>{{ $t->reservasi->kode }}</span>
                    <b>{{ $t->reservasi->user->name }}</b>
                    <span>{{ $t->reservasi->jadwal->lapangan->nama }}</span>
                    <b>@rupiah($t->nominal)</b>
                    <span><x-chip :status="$t->status" /></span>
                </div>
            @endforeach
        </div>
    </div>
@endif
@endsection
