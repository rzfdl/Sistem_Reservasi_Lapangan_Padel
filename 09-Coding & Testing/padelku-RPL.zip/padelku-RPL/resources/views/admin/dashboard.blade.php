@extends('layouts.admin')
@section('title', 'Dashboard')
@section('heading', 'Dashboard')
@section('sub', 'Ringkasan operasional lapangan hari ini.')
@section('content')
<div class="stats4">
    <div class="stat"><span class="n">{{ $menunggu }}</span><span class="l">Menunggu verifikasi</span></div>
    <div class="stat"><span class="n">{{ $hariIni }}</span><span class="l">Reservasi hari ini</span></div>
    <div class="stat"><span class="n">{{ $jumlahLapangan }}</span><span class="l">Lapangan aktif</span></div>
    <div class="stat"><span class="n" style="font-size:28px">@rupiah($bulanIni)</span><span class="l">Pembayaran diterima bulan ini</span></div>
</div>

<div class="dash2">
    <div class="card flush">
        <div style="padding:24px 24px 16px"><h2>Perlu diverifikasi</h2><p class="hint">Bukti pembayaran yang menunggu keputusanmu.</p></div>
        <div class="tbl">
            @php $kolom = 'grid-template-columns:1fr 1.2fr 1.4fr 120px'; @endphp
            <div class="tr th" style="{{ $kolom }}"><span>Pelanggan</span><span>Lapangan</span><span>Jadwal</span><span></span></div>
            @forelse ($antrean as $r)
                <div class="tr" style="{{ $kolom }}">
                    <span><b>{{ $r->user->name }}</b><small>{{ $r->kode }}</small></span>
                    <span>{{ $r->jadwal->lapangan->nama }}</span>
                    <span>{{ $r->jadwal->tanggal->translatedFormat('D, j M') }}, {{ $r->jadwal->label_jam }}</span>
                    <span class="acts"><a class="btn ghost sm" href="{{ route('admin.verifikasi.index', ['id' => $r->id]) }}">Periksa</a></span>
                </div>
            @empty
                <div class="tr" style="grid-template-columns:1fr"><span class="hint">Tidak ada bukti yang menunggu verifikasi.</span></div>
            @endforelse
        </div>
    </div>
    <div class="card">
        <h2>Slot terisi hari ini</h2>
        <p class="sub">{{ today()->translatedFormat('l, j F Y') }}</p>
        @foreach ($okupansi as $o)
            <div class="occ"><span class="nm">{{ $o['nama'] }}</span><div class="track"><i style="width:{{ $o['persen'] }}%"></i></div><span class="pc">{{ $o['persen'] }}%</span></div>
        @endforeach
    </div>
</div>
@endsection
