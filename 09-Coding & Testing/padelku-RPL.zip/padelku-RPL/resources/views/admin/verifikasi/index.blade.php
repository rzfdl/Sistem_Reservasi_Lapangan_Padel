@extends('layouts.admin')
@section('title', 'Verifikasi pembayaran')
@section('heading', 'Verifikasi pembayaran')
@section('sub', 'Periksa bukti pembayaran yang diunggah pelanggan.')
@section('content')
@if ($antrean->isEmpty())
    <div class="empty">
        <div class="eico"><x-icon name="shield" :size="44" color="#1B4FB5" /></div>
        <h2>Tidak ada bukti yang menunggu</h2>
        <p>Semua bukti pembayaran sudah diverifikasi.</p>
    </div>
@else
<div class="ver">
    <div class="card flush">
        <div style="padding:20px 22px;border-bottom:1px solid #E1E7F0"><h2>Menunggu verifikasi</h2><span class="hint">{{ $antrean->count() }} reservasi</span></div>
        @foreach ($antrean as $r)
            <a class="vi {{ $r->id === $dipilih->id ? 'on' : '' }}" href="{{ route('admin.verifikasi.index', ['id' => $r->id]) }}">
                <b>{{ $r->user->name }}</b>
                <span>{{ $r->kode }}, {{ $r->jadwal->lapangan->nama }}</span>
                <span>Diunggah {{ $r->pembayaranTerakhir->created_at->translatedFormat('j M, H.i') }}</span>
            </a>
        @endforeach
    </div>

    @php $p = $dipilih->pembayaranTerakhir; @endphp
    <div class="card">
        <div class="vhead"><h2>{{ $dipilih->kode }}</h2><x-chip :status="$dipilih->status" /></div>
        <div class="vbody">
            <div>
                <div class="kv"><span>Pelanggan</span><b>{{ $dipilih->user->name }}</b></div>
                <div class="kv"><span>Lapangan</span><b>{{ $dipilih->jadwal->lapangan->nama }}</b></div>
                <div class="kv"><span>Tanggal</span><b>{{ $dipilih->jadwal->tanggal->translatedFormat('l, j F Y') }}</b></div>
                <div class="kv"><span>Jam main</span><b>{{ $dipilih->jadwal->label_jam }}</b></div>
                <div class="kv"><span>Nominal</span><b>@rupiah($p->nominal)</b></div>
                <div class="kv"><span>Diunggah</span><b>{{ $p->created_at->translatedFormat('j M, H.i') }}</b></div>
            </div>
            <div class="viewer">
                @if ($p->bukti_gambar)
                    <img src="{{ route('bukti', $p) }}" alt="Bukti pembayaran" style="width:100%;border-radius:10px;background:#fff">
                @else
                    <div class="receipt"><x-icon name="file" :size="40" color="#1B4FB5" /><b>Bukti berformat PDF</b></div>
                @endif
                <span class="hint">{{ basename($p->bukti_path) }}</span>
                <a class="btn ghost sm" target="_blank" href="{{ route('bukti', $p) }}"><x-icon name="eye" :size="16" />Buka ukuran penuh</a>
            </div>
        </div>
        <div class="alert info">
            <x-icon name="info" :size="20" color="#17408F" />
            <div>Jika diterima, status menjadi Terkonfirmasi. Jika ditolak, status kembali ke Menunggu Pembayaran dan pelanggan bisa mengunggah ulang bukti.</div>
        </div>
        <div class="actbar">
            <form method="POST" action="{{ route('admin.verifikasi.tolak', $p) }}" onsubmit="return confirm('Tolak bukti pembayaran ini?')">
                @csrf
                <button type="submit" class="btn dangero"><x-icon name="x" :size="18" color="#B42318" :w="2.2" />Tolak bukti</button>
            </form>
            <form method="POST" action="{{ route('admin.verifikasi.terima', $p) }}">
                @csrf
                <button type="submit" class="btn primary"><x-icon name="check" :size="18" color="#fff" :w="2.4" />Terima pembayaran</button>
            </form>
        </div>
    </div>
</div>
@endif
@endsection
