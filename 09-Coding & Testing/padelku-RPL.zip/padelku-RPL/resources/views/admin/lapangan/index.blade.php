@extends('layouts.admin')
@section('title', 'Manajemen lapangan')
@section('heading', 'Manajemen lapangan')
@section('sub', 'Kelola data lapangan yang tampil di jadwal.')
@section('actions')
    <button type="button" class="btn primary" id="btnTambah"><x-icon name="plus" :size="18" color="#fff" :w="2.2" />Tambah lapangan</button>
@endsection
@section('content')
@if ($errors->any() && ! $errors->has('hapus'))
    <div class="alert err">
        <x-icon name="alert" :size="20" color="#8F1D1D" />
        <div><b>Data belum bisa disimpan</b>{{ implode(' ', $errors->all()) }}</div>
    </div>
@endif

<div class="card flush">
    <div class="tbl">
        @php $kolom = 'grid-template-columns:1.2fr 1fr 3fr 210px'; @endphp
        <div class="tr th" style="{{ $kolom }}"><span>Nama lapangan</span><span>Harga sewa</span><span>Keterangan</span><span></span></div>
        @forelse ($lapangans as $l)
            <div class="tr" style="{{ $kolom }}">
                <b>{{ $l->nama }}</b>
                <span>@rupiah($l->harga_sewa)/jam</span>
                <span>{{ $l->keterangan }}</span>
                <span class="acts">
                    <button type="button" class="btn ghost sm js-ubah" data-id="{{ $l->id }}" data-nama="{{ $l->nama }}" data-harga="{{ $l->harga_sewa }}" data-ket="{{ $l->keterangan }}"><x-icon name="pencil" :size="16" />Ubah</button>
                    <button type="button" class="btn dangero sm js-hapus" data-id="{{ $l->id }}" data-nama="{{ $l->nama }}"><x-icon name="trash" :size="16" color="#B42318" />Hapus</button>
                </span>
            </div>
        @empty
            <div class="tr" style="grid-template-columns:1fr"><span class="hint">Belum ada lapangan. Klik Tambah lapangan untuk memulai.</span></div>
        @endforelse
    </div>
</div>

{{-- FR-3 / FR-4: modal tambah dan ubah --}}
<div class="overlay" id="modalForm">
    <form class="modal" id="formLapangan" method="POST" action="{{ route('admin.lapangan.store') }}">
        @csrf
        <input type="hidden" name="_method" value="PUT" id="fMethod" disabled>
        <div style="display:flex;justify-content:space-between;align-items:center">
            <h2 id="judulModal">Tambah lapangan</h2>
            <button type="button" class="js-tutup" style="background:none;border:0;cursor:pointer;display:flex" aria-label="Tutup"><x-icon name="x" :size="22" color="#5B6B82" /></button>
        </div>
        <div class="field"><label for="fNama">Nama lapangan</label><div class="input"><input id="fNama" name="nama" placeholder="Contoh: Lapangan 5" required maxlength="100"></div></div>
        <div class="field"><label for="fHarga">Harga sewa per jam</label><div class="input"><span class="pre">Rp</span><input id="fHarga" name="harga_sewa" inputmode="numeric" placeholder="0" required></div></div>
        <div class="field"><label for="fKet">Keterangan</label><div class="input area"><textarea id="fKet" name="keterangan" placeholder="Tulis fasilitas atau jenis lapangan" maxlength="500"></textarea></div></div>
        <div class="mact"><button type="button" class="btn ghost js-tutup">Batal</button><button type="submit" class="btn primary">Simpan lapangan</button></div>
    </form>
</div>

{{-- FR-5 / NFR-06: konfirmasi hapus --}}
<div class="overlay" id="modalHapus">
    <form class="modal" id="formHapus" method="POST" action="#">
        @csrf
        @method('DELETE')
        <div class="mico" style="background:#FEE2E2"><x-icon name="trash" :size="26" color="#B42318" /></div>
        <h2 id="judulHapus">Hapus lapangan?</h2>
        <p>Data lapangan ini akan dihapus dari daftar. Tindakan ini tidak bisa dibatalkan.</p>
        <div class="mact"><button type="button" class="btn ghost js-tutup">Batal</button><button type="submit" class="btn danger">Ya, hapus lapangan</button></div>
    </form>
</div>
@endsection
@push('scripts')
<script>
(function () {
    var urlSimpan = "{{ route('admin.lapangan.store') }}";
    var urlUbah = "{{ route('admin.lapangan.update', 0) }}";
    var urlHapus = "{{ route('admin.lapangan.destroy', 0) }}";
    var modalForm = document.getElementById('modalForm'), modalHapus = document.getElementById('modalHapus');
    var form = document.getElementById('formLapangan');

    function buka(el) { el.classList.add('open'); }
    function tutup() { modalForm.classList.remove('open'); modalHapus.classList.remove('open'); }

    document.getElementById('btnTambah').addEventListener('click', function () {
        form.action = urlSimpan; document.getElementById('fMethod').disabled = true;
        document.getElementById('judulModal').textContent = 'Tambah lapangan';
        form.reset(); buka(modalForm); document.getElementById('fNama').focus();
    });
    document.querySelectorAll('.js-ubah').forEach(function (b) {
        b.addEventListener('click', function () {
            form.action = urlUbah.replace(/0$/, b.dataset.id); document.getElementById('fMethod').disabled = false;
            document.getElementById('judulModal').textContent = 'Ubah lapangan';
            document.getElementById('fNama').value = b.dataset.nama;
            document.getElementById('fHarga').value = b.dataset.harga;
            document.getElementById('fKet').value = b.dataset.ket;
            buka(modalForm);
        });
    });
    document.querySelectorAll('.js-hapus').forEach(function (b) {
        b.addEventListener('click', function () {
            document.getElementById('formHapus').action = urlHapus.replace(/0$/, b.dataset.id);
            document.getElementById('judulHapus').textContent = 'Hapus ' + b.dataset.nama + '?';
            buka(modalHapus);
        });
    });
    document.querySelectorAll('.js-tutup').forEach(function (b) { b.addEventListener('click', tutup); });
})();
</script>
@endpush
