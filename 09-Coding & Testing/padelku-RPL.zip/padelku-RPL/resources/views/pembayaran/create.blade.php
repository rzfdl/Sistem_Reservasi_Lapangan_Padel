@extends('layouts.app')
@section('title', 'Unggah bukti pembayaran')
@section('content')
<div class="page">
    @include('partials.flash')
    <div class="phead">
        <div><h1>Unggah bukti pembayaran</h1><p>Reservasi tersimpan. Tinggal satu langkah lagi.</p></div>
        <x-flow :step="2" />
    </div>

    <div class="two">
        <form class="card" method="POST" action="{{ route('pembayaran.store', $reservasi) }}" enctype="multipart/form-data">
            @csrf
            <h2>Unggah bukti pembayaran/DP</h2>
            <p class="sub">Unggah bukti transfer agar admin bisa memverifikasi reservasimu.</p>

            <div style="display:flex;flex-direction:column;gap:20px">
                <label class="drop" id="dropzone" for="bukti" style="cursor:pointer">
                    <span class="ico"><x-icon name="upload" :size="26" color="#1B4FB5" /></span>
                    <b>Tarik file ke sini</b>
                    <span class="hint">atau pilih dari perangkat. Format JPG, PNG, PDF, maksimal 5 MB.</span>
                    <span class="btn ghost sm">Pilih file</span>
                </label>
                <input type="file" id="bukti" name="bukti" accept=".jpg,.jpeg,.png,.pdf" hidden>

                {{-- FR-11: File Tidak Valid --}}
                <div class="file {{ $errors->has('bukti') ? 'err' : '' }}" id="fileRow" @unless ($errors->has('bukti')) hidden @endunless>
                    <span class="fthumb"><x-icon name="file" :size="22" color="#1B4FB5" /></span>
                    <div class="fmeta">
                        <b id="fName">{{ $errors->has('bukti') ? 'File bukti' : '' }}</b>
                        <span id="fMeta">@error('bukti'){{ $message }}. Gunakan JPG, PNG, atau PDF dengan ukuran maksimal 5 MB.@enderror</span>
                    </div>
                </div>

                <div class="field">
                    <label for="nominal">Nominal yang dibayar</label>
                    <div class="input {{ $errors->has('nominal') ? 'err' : '' }}">
                        <span class="pre">Rp</span>
                        <input id="nominal" name="nominal" inputmode="numeric" value="{{ old('nominal') }}" placeholder="50.000">
                    </div>
                    @error('nominal')<span class="errtxt">{{ $message }}</span>@enderror
                </div>

                <div style="display:flex;gap:12px;justify-content:flex-end">
                    <a class="btn ghost" href="{{ route('reservasi.index') }}">Batal</a>
                    <button type="submit" class="btn primary" id="btnUp" disabled>Unggah bukti</button>
                </div>
            </div>
        </form>

        <aside class="col">
            <div class="card">
                <h2 style="margin-bottom:8px">Reservasi kamu</h2>
                <div class="kv"><span>Kode</span><b>{{ $reservasi->kode }}</b></div>
                <div class="kv"><span>Lapangan</span><b>{{ $reservasi->jadwal->lapangan->nama }}</b></div>
                <div class="kv"><span>Tanggal</span><b>{{ $reservasi->jadwal->tanggal->translatedFormat('l, j F Y') }}</b></div>
                <div class="kv"><span>Jam main</span><b>{{ $reservasi->jadwal->label_jam }}</b></div>
                <div class="kv total"><span>Status</span><x-chip :status="$reservasi->status" /></div>
            </div>
            <div class="card">
                <h2>Ketentuan bukti</h2>
                <div class="rules">
                    @foreach (['Format JPG, PNG, atau PDF', 'Ukuran file maksimal 5 MB', 'Setelah diunggah, status berubah menjadi Menunggu Verifikasi', 'Jika ditolak admin, kamu bisa mengunggah ulang'] as $aturan)
                        <div><x-icon name="check" :size="18" color="#14A06B" :w="2.2" /><span>{{ $aturan }}</span></div>
                    @endforeach
                </div>
            </div>
        </aside>
    </div>
</div>
@endsection
@push('scripts')
<script>
(function () {
    var input = document.getElementById('bukti'), row = document.getElementById('fileRow'),
        nama = document.getElementById('fName'), meta = document.getElementById('fMeta'),
        btn = document.getElementById('btnUp'), zone = document.getElementById('dropzone');

    function periksa() {
        var f = input.files[0];
        if (!f) { return; }
        var ok = /\.(jpe?g|png|pdf)$/i.test(f.name) && f.size <= 5 * 1024 * 1024;
        row.hidden = false;
        row.classList.toggle('err', !ok);
        nama.textContent = f.name;
        meta.textContent = ok
            ? (f.size / 1048576).toFixed(1).replace('.', ',') + ' MB, siap diunggah'
            : 'File Tidak Valid. Gunakan JPG, PNG, atau PDF dengan ukuran maksimal 5 MB.';
        btn.disabled = !ok;
    }
    input.addEventListener('change', periksa);
    ['dragover', 'drop'].forEach(function (e) { zone.addEventListener(e, function (ev) { ev.preventDefault(); }); });
    zone.addEventListener('drop', function (ev) { input.files = ev.dataTransfer.files; periksa(); });
})();
</script>
@endpush
