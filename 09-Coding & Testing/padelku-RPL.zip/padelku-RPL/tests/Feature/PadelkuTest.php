<?php

namespace Tests\Feature;

use App\Models\Jadwal;
use App\Models\Lapangan;
use App\Models\Pembayaran;
use App\Models\Reservasi;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class PadelkuTest extends TestCase
{
    use RefreshDatabase;

    private function slot(): Jadwal
    {
        $l = Lapangan::create(['nama' => 'Lapangan Uji', 'harga_sewa' => 150000]);

        return Jadwal::where('lapangan_id', $l->id)
            ->whereDate('tanggal', today()->addDay())
            ->where('jam_mulai', '10:00:00')->firstOrFail();
    }

    private function user(string $role = 'pelanggan'): User
    {
        return User::create([
            'name' => 'Uji '.uniqid(), 'username' => 'u'.uniqid(), 'email' => uniqid().'@uji.test',
            'password' => 'rahasia123', 'role' => $role,
        ]);
    }

    public function test_login_salah_menampilkan_pesan_error(): void
    {
        $u = $this->user();

        $this->post('/login', ['username' => $u->username, 'password' => 'salah'])
            ->assertSessionHasErrors(['login' => 'Username atau Password salah']);
    }

    public function test_login_benar_mengarah_sesuai_role(): void
    {
        $admin = $this->user('admin');
        $this->post('/login', ['username' => $admin->username, 'password' => 'rahasia123'])
            ->assertRedirect(route('admin.dashboard'));
    }

    public function test_jadwal_bisa_dilihat_tanpa_login(): void
    {
        $this->slot();
        $this->get('/jadwal')->assertOk();
    }

    public function test_pelanggan_tidak_bisa_membuka_halaman_admin(): void
    {
        $this->actingAs($this->user())->get('/admin/lapangan')->assertForbidden();
    }

    public function test_slot_tidak_bisa_dipesan_dua_kali(): void
    {
        $slot = $this->slot();

        $this->actingAs($this->user())->post('/reservasi', ['jadwal_id' => $slot->id])->assertRedirect();
        $this->actingAs($this->user())->post('/reservasi', ['jadwal_id' => $slot->id])->assertSessionHas('slot_terisi');

        $this->assertSame(1, Reservasi::count());
    }

    public function test_upload_file_tidak_valid_ditolak_dan_status_tidak_berubah(): void
    {
        Storage::fake('local');
        $slot = $this->slot();
        $u = $this->user();
        $this->actingAs($u)->post('/reservasi', ['jadwal_id' => $slot->id]);
        $r = Reservasi::first();

        $this->post(route('pembayaran.store', $r), [
            'bukti' => UploadedFile::fake()->create('kuitansi.docx', 100),
            'nominal' => '50.000',
        ])->assertSessionHasErrors('bukti');

        $this->assertSame(Reservasi::MENUNGGU_PEMBAYARAN, $r->fresh()->status);
        $this->assertSame(0, Pembayaran::count());
    }

    public function test_alur_upload_lalu_verifikasi_terima_dan_tolak(): void
    {
        Storage::fake('local');
        $slot = $this->slot();
        $u = $this->user();
        $admin = $this->user('admin');

        $this->actingAs($u)->post('/reservasi', ['jadwal_id' => $slot->id]);
        $r = Reservasi::first();

        $this->post(route('pembayaran.store', $r), [
            'bukti' => UploadedFile::fake()->create('bukti.pdf', 100, 'application/pdf'),
            'nominal' => '50.000',
        ])->assertRedirect(route('reservasi.index'));
        $this->assertSame(Reservasi::MENUNGGU_VERIFIKASI, $r->fresh()->status);

        $p = Pembayaran::first();

        // ditolak -> kembali Menunggu Pembayaran
        $this->actingAs($admin)->post(route('admin.verifikasi.tolak', $p))->assertRedirect();
        $this->assertSame(Reservasi::MENUNGGU_PEMBAYARAN, $r->fresh()->status);
        $this->assertSame(Pembayaran::DITOLAK, $p->fresh()->status);

        // unggah ulang lalu diterima -> Terkonfirmasi
        $this->actingAs($u)->post(route('pembayaran.store', $r), [
            'bukti' => UploadedFile::fake()->create('bukti2.pdf', 100, 'application/pdf'),
            'nominal' => '50000',
        ]);
        $p2 = Pembayaran::latest('id')->first();
        $this->actingAs($admin)->post(route('admin.verifikasi.terima', $p2));
        $this->assertSame(Reservasi::TERKONFIRMASI, $r->fresh()->status);
    }
}
