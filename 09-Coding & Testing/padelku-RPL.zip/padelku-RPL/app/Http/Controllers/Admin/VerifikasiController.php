<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pembayaran;
use App\Models\Reservasi;
use Illuminate\Support\Facades\DB;

class VerifikasiController extends Controller
{
    /** FR-13 */
    public function index()
    {
        $antrean = Reservasi::with(['user', 'jadwal.lapangan', 'pembayaranTerakhir'])
            ->where('status', Reservasi::MENUNGGU_VERIFIKASI)
            ->oldest('updated_at')->get();

        $dipilih = $antrean->firstWhere('id', (int) request('id')) ?? $antrean->first();

        return view('admin.verifikasi.index', compact('antrean', 'dipilih'));
    }

    /** FR-14: diterima -> Terkonfirmasi */
    public function terima(Pembayaran $pembayaran)
    {
        return $this->putuskan($pembayaran, true);
    }

    /** FR-14: ditolak -> kembali Menunggu Pembayaran */
    public function tolak(Pembayaran $pembayaran)
    {
        return $this->putuskan($pembayaran, false);
    }

    private function putuskan(Pembayaran $pembayaran, bool $diterima)
    {
        $reservasi = $pembayaran->reservasi;

        if ($pembayaran->status !== Pembayaran::MENUNGGU || $reservasi->status !== Reservasi::MENUNGGU_VERIFIKASI) {
            return redirect()->route('admin.verifikasi.index')
                ->withErrors(['verifikasi' => 'Pembayaran ini sudah diproses.']);
        }

        DB::transaction(function () use ($pembayaran, $reservasi, $diterima) {
            $pembayaran->update([
                'status' => $diterima ? Pembayaran::DITERIMA : Pembayaran::DITOLAK,
                'diverifikasi_at' => now(),
            ]);
            $reservasi->update([
                'status' => $diterima ? Reservasi::TERKONFIRMASI : Reservasi::MENUNGGU_PEMBAYARAN,
            ]);
        });

        return redirect()->route('admin.verifikasi.index')->with('sukses', $diterima
            ? "Pembayaran {$reservasi->kode} diterima. Reservasi Terkonfirmasi."
            : "Bukti {$reservasi->kode} ditolak. Pelanggan bisa mengunggah ulang bukti.");
    }
}
