<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pembayaran;
use Carbon\Carbon;
use Illuminate\Http\Request;

class LaporanController extends Controller
{
    /** FR-15 */
    public function index(Request $request)
    {
        $request->validate([
            'dari' => ['nullable', 'date'],
            'sampai' => ['nullable', 'date', 'after_or_equal:dari'],
        ], [
            'dari.date' => 'Tanggal awal tidak valid',
            'sampai.date' => 'Tanggal akhir tidak valid',
            'sampai.after_or_equal' => 'Tanggal akhir tidak boleh sebelum tanggal awal',
        ]);

        $dari = Carbon::parse($request->input('dari', now()->startOfMonth()->toDateString()))->startOfDay();
        $sampai = Carbon::parse($request->input('sampai', now()->toDateString()))->endOfDay();

        $transaksi = Pembayaran::with(['reservasi.user', 'reservasi.jadwal.lapangan'])
            ->whereBetween('created_at', [$dari, $sampai])
            ->latest()->get();

        return view('admin.laporan.index', [
            'dari' => $dari,
            'sampai' => $sampai,
            'transaksi' => $transaksi,
            'totalDiterima' => (int) $transaksi->where('status', Pembayaran::DITERIMA)->sum('nominal'),
            'jumlahDiterima' => $transaksi->where('status', Pembayaran::DITERIMA)->count(),
            'jumlahDitolak' => $transaksi->where('status', Pembayaran::DITOLAK)->count(),
        ]);
    }
}
