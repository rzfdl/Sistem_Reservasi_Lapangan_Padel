<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Jadwal;
use App\Models\Lapangan;
use App\Models\Pembayaran;
use App\Models\Reservasi;

class DashboardController extends Controller
{
    public function index()
    {
        $lapangans = Lapangan::orderBy('id')->get();

        $okupansi = $lapangans->map(function ($l) {
            $total = Jadwal::where('lapangan_id', $l->id)->whereDate('tanggal', today())->count();
            $terisi = Jadwal::where('lapangan_id', $l->id)->whereDate('tanggal', today())->has('reservasi')->count();

            return ['nama' => $l->nama, 'persen' => $total ? round($terisi / $total * 100) : 0];
        });

        return view('admin.dashboard', [
            'menunggu' => Reservasi::where('status', Reservasi::MENUNGGU_VERIFIKASI)->count(),
            'hariIni' => Reservasi::whereHas('jadwal', fn ($q) => $q->whereDate('tanggal', today()))->count(),
            'jumlahLapangan' => $lapangans->count(),
            'bulanIni' => (int) Pembayaran::where('status', Pembayaran::DITERIMA)
                ->whereBetween('diverifikasi_at', [now()->startOfMonth(), now()->endOfMonth()])->sum('nominal'),
            'antrean' => Reservasi::with(['user', 'jadwal.lapangan'])
                ->where('status', Reservasi::MENUNGGU_VERIFIKASI)->oldest('updated_at')->take(3)->get(),
            'okupansi' => $okupansi,
        ]);
    }
}
