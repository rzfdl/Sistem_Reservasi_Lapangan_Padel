<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lapangan;
use Illuminate\Http\Request;

class LapanganController extends Controller
{
    public function index()
    {
        return view('admin.lapangan.index', ['lapangans' => Lapangan::orderBy('id')->get()]);
    }

    /** FR-3 */
    public function store(Request $request)
    {
        $lapangan = Lapangan::create($this->validasi($request));

        return redirect()->route('admin.lapangan.index')
            ->with('sukses', "{$lapangan->nama} berhasil ditambahkan.");
    }

    /** FR-4 */
    public function update(Request $request, Lapangan $lapangan)
    {
        $lapangan->update($this->validasi($request));

        return redirect()->route('admin.lapangan.index')
            ->with('sukses', "{$lapangan->nama} berhasil diperbarui.");
    }

    /** FR-5 dan NFR-06: penghapusan hanya lewat konfirmasi di modal. */
    public function destroy(Lapangan $lapangan)
    {
        if ($lapangan->punyaReservasi()) {
            return redirect()->route('admin.lapangan.index')
                ->withErrors(['hapus' => "{$lapangan->nama} masih memiliki reservasi dan tidak bisa dihapus."]);
        }

        $nama = $lapangan->nama;
        $lapangan->delete();

        return redirect()->route('admin.lapangan.index')->with('sukses', "{$nama} berhasil dihapus.");
    }

    private function validasi(Request $request): array
    {
        $request->merge(['harga_sewa' => preg_replace('/\D/', '', (string) $request->input('harga_sewa'))]);

        return $request->validate([
            'nama' => ['required', 'string', 'max:100'],
            'harga_sewa' => ['required', 'integer', 'min:0', 'max:100000000'],
            'keterangan' => ['nullable', 'string', 'max:500'],
        ], [
            'nama.required' => 'Nama lapangan wajib diisi',
            'harga_sewa.required' => 'Harga sewa wajib diisi',
            'harga_sewa.integer' => 'Harga sewa harus berupa angka',
        ]);
    }
}
