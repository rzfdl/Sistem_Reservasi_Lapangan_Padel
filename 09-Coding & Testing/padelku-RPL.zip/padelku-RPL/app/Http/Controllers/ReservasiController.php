<?php

namespace App\Http\Controllers;

use App\Models\Jadwal;
use App\Models\Lapangan;
use App\Models\Reservasi;
use Carbon\Carbon;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReservasiController extends Controller
{
    /** Form reservasi (pilih lapangan, tanggal, jam). */
    public function create(Request $request)
    {
        $lapangans = Lapangan::orderBy('id')->get();

        $dipilih = null;
        if ($request->filled('jadwal_id')) {
            $dipilih = Jadwal::with('reservasi:id,jadwal_id')->find($request->query('jadwal_id'));
        }

        $lapanganId = (int) ($request->query('lapangan_id') ?: $dipilih?->lapangan_id ?: $lapangans->first()?->id);
        try {
            $tgl = $request->filled('tanggal')
                ? Carbon::parse($request->query('tanggal'))->startOfDay()
                : ($dipilih?->tanggal?->copy() ?? Carbon::today());
        } catch (\Throwable) {
            $tgl = Carbon::today();
        }
        if ($tgl->lt(Carbon::today())) {
            $tgl = Carbon::today();
        }

        $lapangan = $lapangans->firstWhere('id', $lapanganId);
        $jadwals = $lapangan
            ? Jadwal::with('reservasi:id,jadwal_id')
                ->where('lapangan_id', $lapangan->id)
                ->whereDate('tanggal', $tgl)
                ->orderBy('jam_mulai')->get()
            : collect();

        // slot terpilih hanya valid bila masih tersedia pada lapangan/tanggal yang ditampilkan
        $dipilih = $jadwals->firstWhere('id', $dipilih?->id);
        if ($dipilih && ! $dipilih->tersedia) {
            $dipilih = null;
        }

        return view('reservasi.create', compact('lapangans', 'lapangan', 'tgl', 'jadwals', 'dipilih'));
    }

    /** FR-8 dan FR-9 */
    public function store(Request $request)
    {
        $data = $request->validate(
            ['jadwal_id' => ['required', 'exists:jadwals,id']],
            ['jadwal_id.required' => 'Pilih slot jam main terlebih dahulu', 'jadwal_id.exists' => 'Slot tidak ditemukan']
        );

        try {
            $reservasi = DB::transaction(function () use ($data, $request) {
                $jadwal = Jadwal::lockForUpdate()->findOrFail($data['jadwal_id']);

                if ($jadwal->lewat || $jadwal->reservasi()->exists()) {
                    return null;
                }

                $r = Reservasi::create([
                    'user_id' => $request->user()->id,
                    'jadwal_id' => $jadwal->id,
                    'status' => Reservasi::MENUNGGU_PEMBAYARAN,
                ]);
                $r->update(['kode' => sprintf('RSV-%04d', $r->id)]);

                return $r;
            });
        } catch (UniqueConstraintViolationException) {
            $reservasi = null; // NFR-17: slot sudah diambil request lain
        }

        if (! $reservasi) {
            return back()->withInput()->with('slot_terisi', true);
        }

        return redirect()->route('pembayaran.create', $reservasi)
            ->with('sukses', 'Reservasi tersimpan dengan status Menunggu Pembayaran.');
    }

    /** FR-10: status reservasi milik pelanggan */
    public function index(Request $request)
    {
        $semua = $request->user()->reservasis()
            ->with(['jadwal.lapangan', 'pembayaranTerakhir'])
            ->latest('id')->get();

        $filter = $request->query('status');
        $daftar = in_array($filter, Reservasi::STATUS, true) ? $semua->where('status', $filter) : $semua;

        return view('reservasi.index', [
            'daftar' => $daftar,
            'total' => $semua->count(),
            'counts' => $semua->countBy('status'),
            'filter' => $filter,
            'statuses' => Reservasi::STATUS,
        ]);
    }
}
