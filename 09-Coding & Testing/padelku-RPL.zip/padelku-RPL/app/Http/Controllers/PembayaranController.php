<?php

namespace App\Http\Controllers;

use App\Models\Pembayaran;
use App\Models\Reservasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class PembayaranController extends Controller
{
    public function create(Request $request, Reservasi $reservasi)
    {
        $this->otorisasi($request, $reservasi);
        $reservasi->load('jadwal.lapangan');

        return view('pembayaran.create', compact('reservasi'));
    }

    /** FR-11 dan FR-12 */
    public function store(Request $request, Reservasi $reservasi)
    {
        $this->otorisasi($request, $reservasi);

        $request->merge(['nominal' => preg_replace('/\D/', '', (string) $request->input('nominal'))]);

        $request->validate([
            'bukti' => ['required', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'],
            'nominal' => ['required', 'integer', 'min:1'],
        ], [
            'bukti.required' => 'File Tidak Valid',
            'bukti.file' => 'File Tidak Valid',
            'bukti.mimes' => 'File Tidak Valid',
            'bukti.max' => 'File Tidak Valid',
            'bukti.uploaded' => 'File Tidak Valid',
            'nominal.required' => 'Isi nominal yang dibayar',
            'nominal.integer' => 'Nominal harus berupa angka',
            'nominal.min' => 'Nominal harus lebih dari 0',
        ]);

        $path = $request->file('bukti')->store('bukti', 'local');

        try {
            DB::transaction(function () use ($reservasi, $path, $request) {
                Pembayaran::create([
                    'reservasi_id' => $reservasi->id,
                    'bukti_path' => $path,
                    'nominal' => (int) $request->input('nominal'),
                    'status' => Pembayaran::MENUNGGU,
                ]);
                $reservasi->update(['status' => Reservasi::MENUNGGU_VERIFIKASI]);
            });
        } catch (\Throwable $e) {
            // NFR-05: tidak ada data yang hilang/setengah tersimpan saat upload gagal
            Storage::disk('local')->delete($path);
            report($e);

            return back()->withErrors(['bukti' => 'Unggah gagal. Data tidak berubah, silakan coba lagi.']);
        }

        return redirect()->route('reservasi.index')
            ->with('sukses', 'Bukti pembayaran terkirim. Admin akan memverifikasi reservasimu.');
    }

    /** Tampilkan file bukti: hanya admin atau pemilik reservasi. */
    public function bukti(Request $request, Pembayaran $pembayaran)
    {
        $user = $request->user();
        abort_unless($user->isAdmin() || $pembayaran->reservasi->user_id === $user->id, 403);
        abort_unless(Storage::disk('local')->exists($pembayaran->bukti_path), 404);

        return Storage::disk('local')->response($pembayaran->bukti_path);
    }

    private function otorisasi(Request $request, Reservasi $reservasi): void
    {
        // NFR-18: pelanggan hanya dapat mengakses reservasi miliknya
        abort_unless($reservasi->user_id === $request->user()->id, 403);
        abort_unless($reservasi->status === Reservasi::MENUNGGU_PEMBAYARAN, 403, 'Reservasi ini tidak sedang menunggu pembayaran.');
    }
}
