<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('auth.login');
    }

    /** FR-1 dan FR-2 */
    public function login(Request $request)
    {
        $data = $request->validate([
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ], [
            'username.required' => 'Username dan Password wajib diisi',
            'password.required' => 'Username dan Password wajib diisi',
        ]);

        if (! Auth::attempt(['username' => $data['username'], 'password' => $data['password']])) {
            return back()
                ->withInput($request->only('username'))
                ->withErrors(['login' => 'Username atau Password salah']);
        }

        $request->session()->regenerate();

        $beranda = Auth::user()->isAdmin() ? route('admin.dashboard') : route('pelanggan.dashboard');

        return redirect()->intended($beranda);
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
