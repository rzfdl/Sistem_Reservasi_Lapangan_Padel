<?php

namespace App\Http\Controllers;

use App\Models\Reservasi;
use Illuminate\Http\Request;

class PelangganController extends Controller
{
    public function dashboard(Request $request)
    {
        $user = $request->user();
        $semua = $user->reservasis()->with(['jadwal.lapangan', 'pembayaranTerakhir'])->get();

        $berikutnya = $semua
            ->where('status', Reservasi::TERKONFIRMASI)
            ->filter(fn ($r) => $r->jadwal->tanggal->gte(today()))
            ->sortBy(fn ($r) => $r->jadwal->tanggal->toDateString().$r->jadwal->jam_mulai)
            ->first();

        return view('pelanggan.dashboard', [
            'berikutnya' => $berikutnya,
            'counts' => $semua->countBy('status'),
            'perlu' => $semua->where('status', Reservasi::MENUNGGU_PEMBAYARAN)->values(),
            'statuses' => Reservasi::STATUS,
        ]);
    }
}
