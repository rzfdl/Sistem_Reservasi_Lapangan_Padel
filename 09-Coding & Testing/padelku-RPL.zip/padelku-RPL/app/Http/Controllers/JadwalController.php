<?php

namespace App\Http\Controllers;

use App\Models\Jadwal;
use App\Models\Lapangan;
use Carbon\Carbon;
use Illuminate\Http\Request;

class JadwalController extends Controller
{
    private const MAKS_HARI = 30;

    /** FR-7: lihat jadwal per tanggal tanpa login */
    public function index(Request $request)
    {
        $hariIni = Carbon::today();
        $tgl = $this->parseTanggal($request->query('tanggal'), $hariIni);

        $lapangans = Lapangan::orderBy('id')->get();
        $jadwals = Jadwal::with('reservasi:id,jadwal_id')
            ->whereDate('tanggal', $tgl)
            ->orderBy('jam_mulai')
            ->get();

        $matrix = [];
        $jamList = [];
        foreach ($jadwals as $j) {
            $matrix[$j->jam_mulai][$j->lapangan_id] = $j;
            $jamList[$j->jam_mulai] = $j->label_jam;
        }

        $kosong = $jadwals->where('tersedia', true)->isEmpty();

        // strip 7 tanggal di sekitar tanggal terpilih
        $awal = $tgl->copy()->subDays(3);
        if ($awal->lt($hariIni)) {
            $awal = $hariIni->copy();
        }
        $strip = collect(range(0, 6))->map(fn ($i) => $awal->copy()->addDays($i));

        $batas = $hariIni->copy()->addDays(self::MAKS_HARI - 1);

        return view('jadwal.index', [
            'tgl' => $tgl,
            'lapangans' => $lapangans,
            'matrix' => $matrix,
            'jamList' => $jamList,
            'kosong' => $kosong,
            'strip' => $strip,
            'min' => $hariIni,
            'max' => $batas,
            'sebelumnya' => $tgl->gt($hariIni) ? $tgl->copy()->subDay() : null,
            'berikutnya' => $tgl->lt($batas) ? $tgl->copy()->addDay() : null,
        ]);
    }

    private function parseTanggal(?string $nilai, Carbon $hariIni): Carbon
    {
        try {
            $tgl = $nilai ? Carbon::parse($nilai)->startOfDay() : $hariIni->copy();
        } catch (\Throwable) {
            return $hariIni->copy();
        }

        if ($tgl->lt($hariIni) || $tgl->gt($hariIni->copy()->addDays(self::MAKS_HARI - 1))) {
            return $hariIni->copy();
        }

        return $tgl;
    }
}
