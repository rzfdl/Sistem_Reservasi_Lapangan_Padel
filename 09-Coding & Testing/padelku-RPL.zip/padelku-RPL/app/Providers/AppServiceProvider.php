<?php

namespace App\Providers;

use Carbon\Carbon;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Carbon::setLocale('id');

        // NFR-10: semua komunikasi memakai HTTPS di production
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }

        // @rupiah($angka) -> Rp150.000
        Blade::directive('rupiah', function ($expression) {
            return "<?php echo 'Rp'.number_format((int) ($expression), 0, ',', '.'); ?>";
        });
    }
}
