<?php

namespace App\Console\Commands;

use App\Models\Jadwal;
use App\Models\Lapangan;
use Illuminate\Console\Command;

class GenerateJadwal extends Command
{
    protected $signature = 'padel:generate-jadwal {--hari=30 : Jumlah hari ke depan}';

    protected $description = 'Membuat slot jadwal per jam untuk semua lapangan';

    public function handle(): int
    {
        $hari = (int) $this->option('hari');

        Lapangan::all()->each(fn (Lapangan $l) => Jadwal::generate($l, null, $hari));

        $this->info("Slot jadwal {$hari} hari ke depan sudah dibuat.");

        return self::SUCCESS;
    }
}
