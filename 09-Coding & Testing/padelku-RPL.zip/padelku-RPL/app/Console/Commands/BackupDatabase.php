<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Facades\Storage;

class BackupDatabase extends Command
{
    protected $signature = 'padel:backup';

    protected $description = 'Backup database transaksi (mysqldump) ke storage/app/private/backup';

    public function handle(): int
    {
        $c = config('database.connections.'.config('database.default'));

        $hasil = Process::run([
            'mysqldump',
            '--host='.$c['host'],
            '--port='.$c['port'],
            '--user='.$c['username'],
            '--password='.$c['password'],
            '--single-transaction',
            $c['database'],
        ]);

        if (! $hasil->successful()) {
            $this->error('Backup gagal: '.$hasil->errorOutput());

            return self::FAILURE;
        }

        $file = 'backup/padelku-'.now()->format('Y-m-d').'.sql';
        Storage::disk('local')->put($file, $hasil->output());
        $this->info("Backup tersimpan: {$file}");

        return self::SUCCESS;
    }
}
