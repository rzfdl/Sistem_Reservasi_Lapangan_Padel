<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Reservasi extends Model
{
    public const MENUNGGU_PEMBAYARAN = 'Menunggu Pembayaran';
    public const MENUNGGU_VERIFIKASI = 'Menunggu Verifikasi';
    public const TERKONFIRMASI = 'Terkonfirmasi';

    /** Urutan alur status (NFR-19). */
    public const STATUS = [self::MENUNGGU_PEMBAYARAN, self::MENUNGGU_VERIFIKASI, self::TERKONFIRMASI];

    protected $fillable = ['kode', 'user_id', 'jadwal_id', 'status'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function jadwal(): BelongsTo
    {
        return $this->belongsTo(Jadwal::class);
    }

    public function pembayarans(): HasMany
    {
        return $this->hasMany(Pembayaran::class);
    }

    public function pembayaranTerakhir(): HasOne
    {
        return $this->hasOne(Pembayaran::class)->latestOfMany();
    }

    /** Tahap 1-3 untuk progress bar status. */
    public function getTahapAttribute(): int
    {
        return array_search($this->status, self::STATUS, true) + 1;
    }

    /** Bukti terakhir ditolak admin, pelanggan perlu mengunggah ulang. */
    public function getDitolakAttribute(): bool
    {
        return $this->status === self::MENUNGGU_PEMBAYARAN
            && $this->pembayaranTerakhir?->status === Pembayaran::DITOLAK;
    }
}
