<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Jadwal extends Model
{
    public const JAM_BUKA = 8;
    public const JAM_TUTUP = 22;

    protected $fillable = ['lapangan_id', 'tanggal', 'jam_mulai', 'jam_selesai'];

    protected function casts(): array
    {
        return ['tanggal' => 'date'];
    }

    public function lapangan(): BelongsTo
    {
        return $this->belongsTo(Lapangan::class);
    }

    public function reservasi(): HasOne
    {
        return $this->hasOne(Reservasi::class);
    }

    /** 19.00–20.00 */
    public function getLabelJamAttribute(): string
    {
        return str_replace(':', '.', substr($this->jam_mulai, 0, 5)).'–'.str_replace(':', '.', substr($this->jam_selesai, 0, 5));
    }

    public function getLewatAttribute(): bool
    {
        return Carbon::parse($this->tanggal->toDateString().' '.$this->jam_mulai)->isPast();
    }

    /** Perlu relasi `reservasi` sudah di-load (with('reservasi')). */
    public function getTersediaAttribute(): bool
    {
        return ! $this->lewat && $this->reservasi === null;
    }

    public static function generate(Lapangan $lapangan, ?Carbon $mulai = null, int $hari = 30): void
    {
        $mulai ??= Carbon::today();
        $rows = [];

        for ($d = 0; $d < $hari; $d++) {
            $tanggal = $mulai->copy()->addDays($d)->toDateString();
            for ($jam = self::JAM_BUKA; $jam < self::JAM_TUTUP; $jam++) {
                $rows[] = [
                    'lapangan_id' => $lapangan->id,
                    'tanggal' => $tanggal,
                    'jam_mulai' => sprintf('%02d:00:00', $jam),
                    'jam_selesai' => sprintf('%02d:00:00', $jam + 1),
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
        }

        foreach (array_chunk($rows, 500) as $chunk) {
            static::insertOrIgnore($chunk);
        }
    }
}
