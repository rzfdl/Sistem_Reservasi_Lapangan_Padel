<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Pembayaran extends Model
{
    public const MENUNGGU = 'Menunggu';
    public const DITERIMA = 'Diterima';
    public const DITOLAK = 'Ditolak';

    protected $fillable = ['reservasi_id', 'bukti_path', 'nominal', 'status', 'diverifikasi_at'];

    protected function casts(): array
    {
        return ['diverifikasi_at' => 'datetime'];
    }

    public function reservasi(): BelongsTo
    {
        return $this->belongsTo(Reservasi::class);
    }

    public function getBuktiGambarAttribute(): bool
    {
        return (bool) preg_match('/\.(jpe?g|png|svg)$/i', $this->bukti_path);
    }
}
