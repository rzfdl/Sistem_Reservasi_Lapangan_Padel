<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Lapangan extends Model
{
    protected $fillable = ['nama', 'harga_sewa', 'keterangan'];

    protected static function booted(): void
    {
        // Lapangan baru otomatis mendapat slot jadwal 30 hari ke depan
        static::created(fn (Lapangan $lapangan) => Jadwal::generate($lapangan));
    }

    public function jadwals(): HasMany
    {
        return $this->hasMany(Jadwal::class);
    }

    public function punyaReservasi(): bool
    {
        return Reservasi::whereHas('jadwal', fn ($q) => $q->where('lapangan_id', $this->id))->exists();
    }
}
