<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
$warna = ['Menunggu Pembayaran' => 'amber', 'Menunggu Verifikasi' => 'blue', 'Terkonfirmasi' => 'green', 'Diterima' => 'green', 'Ditolak' => 'red', 'Menunggu' => 'blue'];
?>
<span class="chip <?php echo e($warna[$status] ?? 'blue'); ?>"><i class="dot"></i><?php echo e($status); ?></span>
<?php /**PATH C:\proyek\padelku\resources\views/components/chip.blade.php ENDPATH**/ ?>