<?php $__env->startSection('title', 'Manajemen lapangan'); ?>
<?php $__env->startSection('heading', 'Manajemen lapangan'); ?>
<?php $__env->startSection('sub', 'Kelola data lapangan yang tampil di jadwal.'); ?>
<?php $__env->startSection('actions'); ?>
    <button type="button" class="btn primary" id="btnTambah"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','size' => 18,'color' => '#fff','w' => 2.2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','size' => 18,'color' => '#fff','w' => 2.2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>Tambah lapangan</button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any() && ! $errors->has('hapus')): ?>
    <div class="alert err">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'alert','size' => 20,'color' => '#8F1D1D']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alert','size' => 20,'color' => '#8F1D1D']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        <div><b>Data belum bisa disimpan</b><?php echo e(implode(' ', $errors->all())); ?></div>
    </div>
<?php endif; ?>

<div class="card flush">
    <div class="tbl">
        <?php $kolom = 'grid-template-columns:1.2fr 1fr 3fr 210px'; ?>
        <div class="tr th" style="<?php echo e($kolom); ?>"><span>Nama lapangan</span><span>Harga sewa</span><span>Keterangan</span><span></span></div>
        <?php $__empty_1 = true; $__currentLoopData = $lapangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="tr" style="<?php echo e($kolom); ?>">
                <b><?php echo e($l->nama); ?></b>
                <span><?php echo 'Rp'.number_format((int) ($l->harga_sewa), 0, ',', '.'); ?>/jam</span>
                <span><?php echo e($l->keterangan); ?></span>
                <span class="acts">
                    <button type="button" class="btn ghost sm js-ubah" data-id="<?php echo e($l->id); ?>" data-nama="<?php echo e($l->nama); ?>" data-harga="<?php echo e($l->harga_sewa); ?>" data-ket="<?php echo e($l->keterangan); ?>"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'pencil','size' => 16]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pencil','size' => 16]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>Ubah</button>
                    <button type="button" class="btn dangero sm js-hapus" data-id="<?php echo e($l->id); ?>" data-nama="<?php echo e($l->nama); ?>"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','size' => 16,'color' => '#B42318']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','size' => 16,'color' => '#B42318']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>Hapus</button>
                </span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="tr" style="grid-template-columns:1fr"><span class="hint">Belum ada lapangan. Klik Tambah lapangan untuk memulai.</span></div>
        <?php endif; ?>
    </div>
</div>


<div class="overlay" id="modalForm">
    <form class="modal" id="formLapangan" method="POST" action="<?php echo e(route('admin.lapangan.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="PUT" id="fMethod" disabled>
        <div style="display:flex;justify-content:space-between;align-items:center">
            <h2 id="judulModal">Tambah lapangan</h2>
            <button type="button" class="js-tutup" style="background:none;border:0;cursor:pointer;display:flex" aria-label="Tutup"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'x','size' => 22,'color' => '#5B6B82']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','size' => 22,'color' => '#5B6B82']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>
        </div>
        <div class="field"><label for="fNama">Nama lapangan</label><div class="input"><input id="fNama" name="nama" placeholder="Contoh: Lapangan 5" required maxlength="100"></div></div>
        <div class="field"><label for="fHarga">Harga sewa per jam</label><div class="input"><span class="pre">Rp</span><input id="fHarga" name="harga_sewa" inputmode="numeric" placeholder="0" required></div></div>
        <div class="field"><label for="fKet">Keterangan</label><div class="input area"><textarea id="fKet" name="keterangan" placeholder="Tulis fasilitas atau jenis lapangan" maxlength="500"></textarea></div></div>
        <div class="mact"><button type="button" class="btn ghost js-tutup">Batal</button><button type="submit" class="btn primary">Simpan lapangan</button></div>
    </form>
</div>


<div class="overlay" id="modalHapus">
    <form class="modal" id="formHapus" method="POST" action="#">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <div class="mico" style="background:#FEE2E2"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trash','size' => 26,'color' => '#B42318']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','size' => 26,'color' => '#B42318']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
        <h2 id="judulHapus">Hapus lapangan?</h2>
        <p>Data lapangan ini akan dihapus dari daftar. Tindakan ini tidak bisa dibatalkan.</p>
        <div class="mact"><button type="button" class="btn ghost js-tutup">Batal</button><button type="submit" class="btn danger">Ya, hapus lapangan</button></div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var urlSimpan = "<?php echo e(route('admin.lapangan.store')); ?>";
    var urlUbah = "<?php echo e(route('admin.lapangan.update', 0)); ?>";
    var urlHapus = "<?php echo e(route('admin.lapangan.destroy', 0)); ?>";
    var modalForm = document.getElementById('modalForm'), modalHapus = document.getElementById('modalHapus');
    var form = document.getElementById('formLapangan');

    function buka(el) { el.classList.add('open'); }
    function tutup() { modalForm.classList.remove('open'); modalHapus.classList.remove('open'); }

    document.getElementById('btnTambah').addEventListener('click', function () {
        form.action = urlSimpan; document.getElementById('fMethod').disabled = true;
        document.getElementById('judulModal').textContent = 'Tambah lapangan';
        form.reset(); buka(modalForm); document.getElementById('fNama').focus();
    });
    document.querySelectorAll('.js-ubah').forEach(function (b) {
        b.addEventListener('click', function () {
            form.action = urlUbah.replace(/0$/, b.dataset.id); document.getElementById('fMethod').disabled = false;
            document.getElementById('judulModal').textContent = 'Ubah lapangan';
            document.getElementById('fNama').value = b.dataset.nama;
            document.getElementById('fHarga').value = b.dataset.harga;
            document.getElementById('fKet').value = b.dataset.ket;
            buka(modalForm);
        });
    });
    document.querySelectorAll('.js-hapus').forEach(function (b) {
        b.addEventListener('click', function () {
            document.getElementById('formHapus').action = urlHapus.replace(/0$/, b.dataset.id);
            document.getElementById('judulHapus').textContent = 'Hapus ' + b.dataset.nama + '?';
            buka(modalHapus);
        });
    });
    document.querySelectorAll('.js-tutup').forEach(function (b) { b.addEventListener('click', tutup); });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\proyek\padelku\resources\views/admin/lapangan/index.blade.php ENDPATH**/ ?>