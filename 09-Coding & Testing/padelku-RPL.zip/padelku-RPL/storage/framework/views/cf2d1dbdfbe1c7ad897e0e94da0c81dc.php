<?php $__env->startSection('title', 'Status reservasi'); ?>
<?php $__env->startSection('content'); ?>
<div class="page">
    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="phead">
        <div><h1>Status reservasi</h1><p>Pantau perkembangan semua reservasimu.</p></div>
    </div>

    <?php if($total === 0): ?>
        
        <div class="empty">
            <div class="eico"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'clip','size' => 44,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clip','size' => 44,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
            <h2>Belum Ada Reservasi</h2>
            <p>Reservasi yang kamu buat akan muncul di sini beserta statusnya.</p>
            <a class="btn primary" href="<?php echo e(route('jadwal')); ?>">Lihat jadwal lapangan</a>
        </div>
    <?php else: ?>
        <div class="pills" style="flex-wrap:wrap">
            <a class="pill <?php echo e(! $filter ? 'on' : ''); ?>" href="<?php echo e(route('reservasi.index')); ?>">Semua (<?php echo e($total); ?>)</a>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="pill <?php echo e($filter === $s ? 'on' : ''); ?>" href="<?php echo e(route('reservasi.index', ['status' => $s])); ?>"><?php echo e($s); ?> (<?php echo e($counts[$s] ?? 0); ?>)</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="rcard">
                <div class="rrow">
                    <div class="rc1"><b><?php echo e($r->jadwal->lapangan->nama); ?></b><span><?php echo e($r->kode); ?></span></div>
                    <div class="rc2"><b><?php echo e($r->jadwal->tanggal->translatedFormat('l, j F Y')); ?></b><span><?php echo e($r->jadwal->label_jam); ?></span></div>
                    <div class="rc3"><?php if (isset($component)) { $__componentOriginale375e741fa8af2e5aa10d29452e1526c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale375e741fa8af2e5aa10d29452e1526c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.progress','data' => ['stage' => $r->tahap]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('progress'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['stage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($r->tahap)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale375e741fa8af2e5aa10d29452e1526c)): ?>
<?php $attributes = $__attributesOriginale375e741fa8af2e5aa10d29452e1526c; ?>
<?php unset($__attributesOriginale375e741fa8af2e5aa10d29452e1526c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale375e741fa8af2e5aa10d29452e1526c)): ?>
<?php $component = $__componentOriginale375e741fa8af2e5aa10d29452e1526c; ?>
<?php unset($__componentOriginale375e741fa8af2e5aa10d29452e1526c); ?>
<?php endif; ?></div>
                    <div class="rc4">
                        <?php if (isset($component)) { $__componentOriginal3e43da63772e725970863e9067088b49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e43da63772e725970863e9067088b49 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chip','data' => ['status' => $r->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($r->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $attributes = $__attributesOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__attributesOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $component = $__componentOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__componentOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?>
                        <?php if($r->status === 'Menunggu Pembayaran'): ?>
                            <a class="btn primary sm" href="<?php echo e(route('pembayaran.create', $r)); ?>"><?php echo e($r->ditolak ? 'Unggah ulang bukti' : 'Unggah bukti'); ?></a>
                        <?php elseif($r->status === 'Menunggu Verifikasi'): ?>
                            <span class="hint">Admin sedang memeriksa bukti</span>
                        <?php else: ?>
                            <span class="hint">Slot sudah menjadi milikmu</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if($r->ditolak): ?>
                    <div class="alert warn">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'alert','size' => 18,'color' => '#7A4A06']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alert','size' => 18,'color' => '#7A4A06']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <div>Bukti pembayaran ditolak admin. Unggah ulang bukti agar reservasi bisa diverifikasi lagi.</div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="hint">Tidak ada reservasi dengan status ini.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\proyek\padelku\resources\views/reservasi/index.blade.php ENDPATH**/ ?>