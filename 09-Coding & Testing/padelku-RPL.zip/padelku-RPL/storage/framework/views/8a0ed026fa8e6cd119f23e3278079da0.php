<?php $__env->startSection('title', 'Unggah bukti pembayaran'); ?>
<?php $__env->startSection('content'); ?>
<div class="page">
    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="phead">
        <div><h1>Unggah bukti pembayaran</h1><p>Reservasi tersimpan. Tinggal satu langkah lagi.</p></div>
        <?php if (isset($component)) { $__componentOriginal21b594e1628e0c301c13dcac5b929c0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21b594e1628e0c301c13dcac5b929c0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flow','data' => ['step' => 2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['step' => 2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21b594e1628e0c301c13dcac5b929c0f)): ?>
<?php $attributes = $__attributesOriginal21b594e1628e0c301c13dcac5b929c0f; ?>
<?php unset($__attributesOriginal21b594e1628e0c301c13dcac5b929c0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21b594e1628e0c301c13dcac5b929c0f)): ?>
<?php $component = $__componentOriginal21b594e1628e0c301c13dcac5b929c0f; ?>
<?php unset($__componentOriginal21b594e1628e0c301c13dcac5b929c0f); ?>
<?php endif; ?>
    </div>

    <div class="two">
        <form class="card" method="POST" action="<?php echo e(route('pembayaran.store', $reservasi)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2>Unggah bukti pembayaran/DP</h2>
            <p class="sub">Unggah bukti transfer agar admin bisa memverifikasi reservasimu.</p>

            <div style="display:flex;flex-direction:column;gap:20px">
                <label class="drop" id="dropzone" for="bukti" style="cursor:pointer">
                    <span class="ico"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'upload','size' => 26,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'upload','size' => 26,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                    <b>Tarik file ke sini</b>
                    <span class="hint">atau pilih dari perangkat. Format JPG, PNG, PDF, maksimal 5 MB.</span>
                    <span class="btn ghost sm">Pilih file</span>
                </label>
                <input type="file" id="bukti" name="bukti" accept=".jpg,.jpeg,.png,.pdf" hidden>

                
                <div class="file <?php echo e($errors->has('bukti') ? 'err' : ''); ?>" id="fileRow" <?php if (! ($errors->has('bukti'))): ?> hidden <?php endif; ?>>
                    <span class="fthumb"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'file','size' => 22,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file','size' => 22,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span>
                    <div class="fmeta">
                        <b id="fName"><?php echo e($errors->has('bukti') ? 'File bukti' : ''); ?></b>
                        <span id="fMeta"><?php $__errorArgs = ['bukti'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?>. Gunakan JPG, PNG, atau PDF dengan ukuran maksimal 5 MB.<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                    </div>
                </div>

                <div class="field">
                    <label for="nominal">Nominal yang dibayar</label>
                    <div class="input <?php echo e($errors->has('nominal') ? 'err' : ''); ?>">
                        <span class="pre">Rp</span>
                        <input id="nominal" name="nominal" inputmode="numeric" value="<?php echo e(old('nominal')); ?>" placeholder="50.000">
                    </div>
                    <?php $__errorArgs = ['nominal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="errtxt"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div style="display:flex;gap:12px;justify-content:flex-end">
                    <a class="btn ghost" href="<?php echo e(route('reservasi.index')); ?>">Batal</a>
                    <button type="submit" class="btn primary" id="btnUp" disabled>Unggah bukti</button>
                </div>
            </div>
        </form>

        <aside class="col">
            <div class="card">
                <h2 style="margin-bottom:8px">Reservasi kamu</h2>
                <div class="kv"><span>Kode</span><b><?php echo e($reservasi->kode); ?></b></div>
                <div class="kv"><span>Lapangan</span><b><?php echo e($reservasi->jadwal->lapangan->nama); ?></b></div>
                <div class="kv"><span>Tanggal</span><b><?php echo e($reservasi->jadwal->tanggal->translatedFormat('l, j F Y')); ?></b></div>
                <div class="kv"><span>Jam main</span><b><?php echo e($reservasi->jadwal->label_jam); ?></b></div>
                <div class="kv total"><span>Status</span><?php if (isset($component)) { $__componentOriginal3e43da63772e725970863e9067088b49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e43da63772e725970863e9067088b49 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chip','data' => ['status' => $reservasi->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reservasi->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $attributes = $__attributesOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__attributesOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $component = $__componentOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__componentOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?></div>
            </div>
            <div class="card">
                <h2>Ketentuan bukti</h2>
                <div class="rules">
                    <?php $__currentLoopData = ['Format JPG, PNG, atau PDF', 'Ukuran file maksimal 5 MB', 'Setelah diunggah, status berubah menjadi Menunggu Verifikasi', 'Jika ditolak admin, kamu bisa mengunggah ulang']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aturan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check','size' => 18,'color' => '#14A06B','w' => 2.2]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check','size' => 18,'color' => '#14A06B','w' => 2.2]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><span><?php echo e($aturan); ?></span></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var input = document.getElementById('bukti'), row = document.getElementById('fileRow'),
        nama = document.getElementById('fName'), meta = document.getElementById('fMeta'),
        btn = document.getElementById('btnUp'), zone = document.getElementById('dropzone');

    function periksa() {
        var f = input.files[0];
        if (!f) { return; }
        var ok = /\.(jpe?g|png|pdf)$/i.test(f.name) && f.size <= 5 * 1024 * 1024;
        row.hidden = false;
        row.classList.toggle('err', !ok);
        nama.textContent = f.name;
        meta.textContent = ok
            ? (f.size / 1048576).toFixed(1).replace('.', ',') + ' MB, siap diunggah'
            : 'File Tidak Valid. Gunakan JPG, PNG, atau PDF dengan ukuran maksimal 5 MB.';
        btn.disabled = !ok;
    }
    input.addEventListener('change', periksa);
    ['dragover', 'drop'].forEach(function (e) { zone.addEventListener(e, function (ev) { ev.preventDefault(); }); });
    zone.addEventListener('drop', function (ev) { input.files = ev.dataTransfer.files; periksa(); });
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\proyek\padelku\resources\views/pembayaran/create.blade.php ENDPATH**/ ?>