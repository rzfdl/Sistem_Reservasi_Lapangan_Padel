<?php $__env->startSection('title', 'Laporan transaksi'); ?>
<?php $__env->startSection('heading', 'Laporan transaksi'); ?>
<?php $__env->startSection('sub', 'Transaksi pembayaran per periode.'); ?>
<?php $__env->startSection('content'); ?>
<form class="card" method="GET" action="<?php echo e(route('admin.laporan.index')); ?>">
    <div style="display:flex;gap:20px;align-items:flex-end;flex-wrap:wrap">
        <div class="field" style="flex:1;min-width:200px"><label for="dari">Dari tanggal</label><div class="input"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'calendar','size' => 18,'color' => '#5B6B82']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','size' => 18,'color' => '#5B6B82']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><input id="dari" type="date" name="dari" value="<?php echo e($dari->toDateString()); ?>"></div></div>
        <div class="field" style="flex:1;min-width:200px"><label for="sampai">Sampai tanggal</label><div class="input"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'calendar','size' => 18,'color' => '#5B6B82']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','size' => 18,'color' => '#5B6B82']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?><input id="sampai" type="date" name="sampai" value="<?php echo e($sampai->toDateString()); ?>"></div></div>
        <button type="submit" class="btn primary">Tampilkan laporan</button>
    </div>
    <?php $__errorArgs = ['sampai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="errtxt" style="margin-top:10px"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['dari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="errtxt" style="margin-top:10px"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="pills" style="margin:16px 0 0;flex-wrap:wrap">
        <a class="pill" href="<?php echo e(route('admin.laporan.index', ['dari' => today()->subDays(6)->toDateString(), 'sampai' => today()->toDateString()])); ?>">7 hari terakhir</a>
        <a class="pill" href="<?php echo e(route('admin.laporan.index', ['dari' => today()->startOfMonth()->toDateString(), 'sampai' => today()->toDateString()])); ?>">Bulan ini</a>
        <a class="pill" href="<?php echo e(route('admin.laporan.index', ['dari' => today()->subMonthNoOverflow()->startOfMonth()->toDateString(), 'sampai' => today()->subMonthNoOverflow()->endOfMonth()->toDateString()])); ?>">Bulan lalu</a>
    </div>
</form>

<?php if($transaksi->isEmpty()): ?>
    <div class="empty">
        <div class="eico"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chart','size' => 44,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chart','size' => 44,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
        <h2>Data Tidak Ditemukan</h2>
        <p>Tidak ada transaksi pembayaran pada periode ini. Ubah rentang tanggal atau pilih periode lain.</p>
    </div>
<?php else: ?>
    <div class="stats">
        <div class="stat"><span class="l">Total pembayaran diterima</span><span class="n"><?php echo 'Rp'.number_format((int) ($totalDiterima), 0, ',', '.'); ?></span></div>
        <div class="stat"><span class="l">Transaksi diterima</span><span class="n"><?php echo e($jumlahDiterima); ?></span></div>
        <div class="stat"><span class="l">Transaksi ditolak</span><span class="n"><?php echo e($jumlahDitolak); ?></span></div>
    </div>
    <div class="card flush">
        <div class="tbl">
            <?php $kolom = 'grid-template-columns:1fr 1fr 1.4fr 1fr 1fr 1fr'; ?>
            <div class="tr th" style="<?php echo e($kolom); ?>"><span>Tanggal</span><span>Kode</span><span>Pelanggan</span><span>Lapangan</span><span>Nominal</span><span>Hasil verifikasi</span></div>
            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tr" style="<?php echo e($kolom); ?>">
                    <span><?php echo e($t->created_at->translatedFormat('j M Y')); ?></span>
                    <span><?php echo e($t->reservasi->kode); ?></span>
                    <b><?php echo e($t->reservasi->user->name); ?></b>
                    <span><?php echo e($t->reservasi->jadwal->lapangan->nama); ?></span>
                    <b><?php echo 'Rp'.number_format((int) ($t->nominal), 0, ',', '.'); ?></b>
                    <span><?php if (isset($component)) { $__componentOriginal3e43da63772e725970863e9067088b49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e43da63772e725970863e9067088b49 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chip','data' => ['status' => $t->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($t->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $attributes = $__attributesOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__attributesOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $component = $__componentOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__componentOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\proyek\padelku\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>