<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('heading', 'Dashboard'); ?>
<?php $__env->startSection('sub', 'Ringkasan operasional lapangan hari ini.'); ?>
<?php $__env->startSection('content'); ?>
<div class="stats4">
    <div class="stat"><span class="n"><?php echo e($menunggu); ?></span><span class="l">Menunggu verifikasi</span></div>
    <div class="stat"><span class="n"><?php echo e($hariIni); ?></span><span class="l">Reservasi hari ini</span></div>
    <div class="stat"><span class="n"><?php echo e($jumlahLapangan); ?></span><span class="l">Lapangan aktif</span></div>
    <div class="stat"><span class="n" style="font-size:28px"><?php echo 'Rp'.number_format((int) ($bulanIni), 0, ',', '.'); ?></span><span class="l">Pembayaran diterima bulan ini</span></div>
</div>

<div class="dash2">
    <div class="card flush">
        <div style="padding:24px 24px 16px"><h2>Perlu diverifikasi</h2><p class="hint">Bukti pembayaran yang menunggu keputusanmu.</p></div>
        <div class="tbl">
            <?php $kolom = 'grid-template-columns:1fr 1.2fr 1.4fr 120px'; ?>
            <div class="tr th" style="<?php echo e($kolom); ?>"><span>Pelanggan</span><span>Lapangan</span><span>Jadwal</span><span></span></div>
            <?php $__empty_1 = true; $__currentLoopData = $antrean; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="tr" style="<?php echo e($kolom); ?>">
                    <span><b><?php echo e($r->user->name); ?></b><small><?php echo e($r->kode); ?></small></span>
                    <span><?php echo e($r->jadwal->lapangan->nama); ?></span>
                    <span><?php echo e($r->jadwal->tanggal->translatedFormat('D, j M')); ?>, <?php echo e($r->jadwal->label_jam); ?></span>
                    <span class="acts"><a class="btn ghost sm" href="<?php echo e(route('admin.verifikasi.index', ['id' => $r->id])); ?>">Periksa</a></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="tr" style="grid-template-columns:1fr"><span class="hint">Tidak ada bukti yang menunggu verifikasi.</span></div>
            <?php endif; ?>
        </div>
    </div>
    <div class="card">
        <h2>Slot terisi hari ini</h2>
        <p class="sub"><?php echo e(today()->translatedFormat('l, j F Y')); ?></p>
        <?php $__currentLoopData = $okupansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="occ"><span class="nm"><?php echo e($o['nama']); ?></span><div class="track"><i style="width:<?php echo e($o['persen']); ?>%"></i></div><span class="pc"><?php echo e($o['persen']); ?>%</span></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\proyek\padelku\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>