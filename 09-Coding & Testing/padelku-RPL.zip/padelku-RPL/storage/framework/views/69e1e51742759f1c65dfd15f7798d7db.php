<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('content'); ?>
<div class="page">
    <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="phead">
        <div><h1>Halo, <?php echo e(\Illuminate\Support\Str::before(auth()->user()->name, ' ')); ?></h1><p>Ini ringkasan reservasi kamu.</p></div>
    </div>
    <div class="jad">
        <div class="col">
            <div class="hero2">
                <div>
                    <?php if($berikutnya): ?>
                        <div class="k">Reservasi terkonfirmasi berikutnya</div>
                        <h2><?php echo e($berikutnya->jadwal->lapangan->nama); ?></h2>
                        <p><?php echo e($berikutnya->jadwal->tanggal->translatedFormat('l, j F Y')); ?>, <?php echo e($berikutnya->jadwal->label_jam); ?></p>
                        <a class="btn ball" href="<?php echo e(route('reservasi.index')); ?>">Lihat status reservasi</a>
                    <?php else: ?>
                        <div class="k">Belum ada reservasi terkonfirmasi</div>
                        <h2>Mau main kapan?</h2>
                        <p>Cek slot kosong lalu pesan lapangan favoritmu.</p>
                        <a class="btn ball" href="<?php echo e(route('jadwal')); ?>">Lihat jadwal lapangan</a>
                    <?php endif; ?>
                </div>
                <?php if (isset($component)) { $__componentOriginal789348e6ab3270c9dc2f10e1e0ff1897 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal789348e6ab3270c9dc2f10e1e0ff1897 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.court','data' => ['w' => 150,'h' => 178]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('court'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['w' => 150,'h' => 178]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal789348e6ab3270c9dc2f10e1e0ff1897)): ?>
<?php $attributes = $__attributesOriginal789348e6ab3270c9dc2f10e1e0ff1897; ?>
<?php unset($__attributesOriginal789348e6ab3270c9dc2f10e1e0ff1897); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal789348e6ab3270c9dc2f10e1e0ff1897)): ?>
<?php $component = $__componentOriginal789348e6ab3270c9dc2f10e1e0ff1897; ?>
<?php unset($__componentOriginal789348e6ab3270c9dc2f10e1e0ff1897); ?>
<?php endif; ?>
            </div>

            <div class="stats">
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="stat"><?php if (isset($component)) { $__componentOriginal3e43da63772e725970863e9067088b49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e43da63772e725970863e9067088b49 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chip','data' => ['status' => $s]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($s)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $attributes = $__attributesOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__attributesOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e43da63772e725970863e9067088b49)): ?>
<?php $component = $__componentOriginal3e43da63772e725970863e9067088b49; ?>
<?php unset($__componentOriginal3e43da63772e725970863e9067088b49); ?>
<?php endif; ?><span class="n"><?php echo e($counts[$s] ?? 0); ?></span><span class="l">reservasi</span></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="card">
                <h2>Perlu tindakan</h2>
                <p class="sub">Unggah bukti DP agar admin bisa memverifikasi reservasimu.</p>
                <?php $__empty_1 = true; $__currentLoopData = $perlu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="arow">
                        <div>
                            <b><?php echo e($r->jadwal->lapangan->nama); ?>, <?php echo e($r->jadwal->tanggal->translatedFormat('l, j F Y')); ?></b>
                            <span class="s"><?php echo e($r->jadwal->label_jam); ?>, <?php echo e($r->kode); ?></span>
                        </div>
                        <a class="btn primary sm" href="<?php echo e(route('pembayaran.create', $r)); ?>"><?php echo e($r->ditolak ? 'Unggah ulang bukti' : 'Unggah bukti'); ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="hint">Tidak ada yang perlu kamu lakukan sekarang.</p>
                <?php endif; ?>
            </div>
        </div>

        <aside class="card">
            <h2 style="margin-bottom:16px">Menu cepat</h2>
            <a class="qa" href="<?php echo e(route('jadwal')); ?>"><span class="qi"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'calendar','size' => 22,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'calendar','size' => 22,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><div>Lihat jadwal lapangan<small>Cek slot kosong per tanggal</small></div></a>
            <a class="qa" href="<?php echo e(route('reservasi.create')); ?>"><span class="qi"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','size' => 22,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','size' => 22,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><div>Buat reservasi<small>Pilih slot dan pesan</small></div></a>
            <a class="qa" href="<?php echo e(route('reservasi.index')); ?>"><span class="qi"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'clip','size' => 22,'color' => '#1B4FB5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clip','size' => 22,'color' => '#1B4FB5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></span><div>Status reservasi<small>Pantau semua reservasimu</small></div></a>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\proyek\padelku\resources\views/pelanggan/dashboard.blade.php ENDPATH**/ ?>