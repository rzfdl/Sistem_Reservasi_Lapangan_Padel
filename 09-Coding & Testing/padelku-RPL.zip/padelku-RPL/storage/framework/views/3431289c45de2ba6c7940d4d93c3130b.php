<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['w' => 440, 'h' => 520]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['w' => 440, 'h' => 520]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<svg width="<?php echo e($w); ?>" height="<?php echo e($h); ?>" viewBox="0 0 440 520" fill="none"><rect x="10" y="10" width="420" height="500" rx="4" fill="#173F94" stroke="#fff" stroke-opacity="0.8" stroke-width="4"/><path d="M10 86H430M10 434H430M220 86V434" stroke="#fff" stroke-opacity="0.8" stroke-width="3"/><path d="M0 260H440" stroke="#fff" stroke-width="6"/><ellipse cx="326" cy="196" rx="14" ry="5" fill="#0B1F3A" fill-opacity="0.3"/><circle cx="320" cy="170" r="16" fill="#CBEA2E"/><path d="M308 160c6 4 6 16 0 20M332 160c-6 4-6 16 0 20" stroke="#0B1F3A" stroke-width="1.6" stroke-linecap="round"/></svg>
<?php /**PATH C:\proyek\padelku\resources\views/components/court.blade.php ENDPATH**/ ?>