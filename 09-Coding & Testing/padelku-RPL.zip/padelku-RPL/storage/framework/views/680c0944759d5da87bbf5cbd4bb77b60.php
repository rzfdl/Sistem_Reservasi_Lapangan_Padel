
<div class="overlay" id="modalSesi">
    <div class="modal">
        <div class="mico" style="background:#FEF3C7"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'clock','size' => 28,'color' => '#92400E']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clock','size' => 28,'color' => '#92400E']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
        <h2>Sesi kamu berakhir</h2>
        <p>Demi keamanan, kamu keluar otomatis setelah 30 menit tidak aktif. Masuk lagi untuk melanjutkan.</p>
        <a class="btn primary block" href="<?php echo e(route('login')); ?>">Masuk lagi</a>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var batas = 30 * 60 * 1000, timer;
    function habis() {
        document.getElementById('modalSesi').classList.add('open');
        fetch('<?php echo e(route("logout")); ?>', {method: 'POST', headers: {'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content}});
    }
    function reset() { clearTimeout(timer); timer = setTimeout(habis, batas); }
    ['click', 'keydown', 'mousemove', 'touchstart'].forEach(function (e) { addEventListener(e, reset, {passive: true}); });
    reset();
})();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\proyek\padelku\resources\views/partials/sesi.blade.php ENDPATH**/ ?>